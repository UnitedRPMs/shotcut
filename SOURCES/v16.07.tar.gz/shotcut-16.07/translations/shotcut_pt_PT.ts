<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pt_PT">
<context>
    <name>AddEncodePresetDialog</name>
    <message>
        <location filename="../src/dialogs/addencodepresetdialog.ui" line="17"/>
        <source>Dialog</source>
        <translation>Diálogo</translation>
    </message>
    <message>
        <location filename="../src/dialogs/addencodepresetdialog.ui" line="25"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../src/dialogs/addencodepresetdialog.ui" line="53"/>
        <source>Make final changes to the preset including removing items you do not want to include, or copy/paste the clipboard.</source>
        <translation>Faça as alterações finais à predefinição incluindo remover itens que não quer incluir, ou copiar/colar da área de transferências.</translation>
    </message>
</context>
<context>
    <name>AlsaWidget</name>
    <message>
        <location filename="../src/widgets/alsawidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../src/widgets/alsawidget.ui" line="26"/>
        <source>ALSA Audio</source>
        <translation>Áudio ALSA</translation>
    </message>
    <message>
        <location filename="../src/widgets/alsawidget.ui" line="54"/>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <location filename="../src/widgets/alsawidget.ui" line="61"/>
        <source>PCM Device</source>
        <translation>Dispositivo PCM</translation>
    </message>
    <message>
        <location filename="../src/widgets/alsawidget.ui" line="71"/>
        <source>default</source>
        <translation>padrão</translation>
    </message>
    <message>
        <location filename="../src/widgets/alsawidget.ui" line="78"/>
        <source>Channels</source>
        <translation>Canais</translation>
    </message>
</context>
<context>
    <name>AttachedFiltersModel</name>
    <message>
        <location filename="../src/models/attachedfiltersmodel.cpp" line="89"/>
        <source>Transition</source>
        <translation type="unfinished">Transição</translation>
    </message>
    <message>
        <location filename="../src/models/attachedfiltersmodel.cpp" line="91"/>
        <source>Track: %1</source>
        <translation>Faixa: %1</translation>
    </message>
    <message>
        <location filename="../src/models/attachedfiltersmodel.cpp" line="93"/>
        <source>Timeline</source>
        <translation>Linha de Tempo</translation>
    </message>
    <message>
        <location filename="../src/models/attachedfiltersmodel.cpp" line="157"/>
        <source>Audio</source>
        <translation>Áudio</translation>
    </message>
    <message>
        <location filename="../src/models/attachedfiltersmodel.cpp" line="159"/>
        <source>GPU</source>
        <translation>GPU</translation>
    </message>
    <message>
        <location filename="../src/models/attachedfiltersmodel.cpp" line="161"/>
        <source>Video</source>
        <translation>Vídeo</translation>
    </message>
</context>
<context>
    <name>AudioLoudnessScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="83"/>
        <source>Momentary Loudness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="86"/>
        <source>Short Term Loudness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="89"/>
        <source>Integrated Loudness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="92"/>
        <source>Loudness Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="95"/>
        <source>Peak</source>
        <translation type="unfinished">Pico</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="98"/>
        <source>True Peak</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="104"/>
        <source>Configure Graphs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="111"/>
        <source>Reset</source>
        <translation type="unfinished">Repor</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="112"/>
        <source>Reset the measurement.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="119"/>
        <source>Time Since Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audioloudnessscopewidget.cpp" line="168"/>
        <source>Audio Loudness</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AudioPeakMeterScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/audiopeakmeterscopewidget.cpp" line="85"/>
        <source>Audio Peak Meter</source>
        <translation>Medidor de Picos Áudio</translation>
    </message>
</context>
<context>
    <name>AudioSpectrumScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/audiospectrumscopewidget.cpp" line="212"/>
        <source>Audio Spectrum</source>
        <translation>Espectro Áudio</translation>
    </message>
</context>
<context>
    <name>AudioWaveformScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/audiowaveformscopewidget.cpp" line="183"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiowaveformscopewidget.cpp" line="184"/>
        <source>-inf</source>
        <translation>-inf</translation>
    </message>
    <message>
        <location filename="../src/widgets/scopes/audiowaveformscopewidget.cpp" line="249"/>
        <source>Audio Waveform</source>
        <translation>Forma de Onda Áudio</translation>
    </message>
</context>
<context>
    <name>AvformatProducerWidget</name>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="36"/>
        <source>Comments:</source>
        <translation>Comentários:</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="64"/>
        <source>Speed</source>
        <translation>Velocidade</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="105"/>
        <source>Duration</source>
        <translation>Duração</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="153"/>
        <source>Video</source>
        <translation>Vídeo</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="161"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="463"/>
        <source>Track</source>
        <translation>Faixa</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="193"/>
        <source>Aspect ratio</source>
        <translation>Proporção</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="224"/>
        <source>:</source>
        <translation>:</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="265"/>
        <source>Scan mode</source>
        <translation>Modo de varredura</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="291"/>
        <source>Interlaced</source>
        <translation>Entrelaçado</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="296"/>
        <source>Progressive</source>
        <translation>Progressivo</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="362"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="392"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="549"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="579"/>
        <source>Codec</source>
        <translation>Codec</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="367"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="397"/>
        <source>Resolution</source>
        <translation>Resolução</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="372"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="402"/>
        <source>Frame rate</source>
        <translation>Taxa de Quadros</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="377"/>
        <source>Pixel format</source>
        <translation>Formato de píxeis</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="382"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="569"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="709"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="387"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="574"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="714"/>
        <source>Value</source>
        <translation>Valor</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="407"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="564"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="594"/>
        <source>Format</source>
        <translation>Formato</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="415"/>
        <source>Field order</source>
        <translation>Ordem dos campos</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="428"/>
        <source>Bottom Field First</source>
        <translation>Campo Inferior Primeiro</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="433"/>
        <source>Top Field First</source>
        <translation>Campo Superior Primeiro</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="457"/>
        <source>Audio</source>
        <translation>Áudio</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="554"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="584"/>
        <source>Channels</source>
        <translation>Canais</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="559"/>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="589"/>
        <source>Sample rate</source>
        <translation>Taxa da Amostra</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="602"/>
        <source>Adjust the audio/video synchronization. The center position is equivalent to no alteration.</source>
        <translation>Ajuste a sincronização áudio/vídeo. A posição central é equivalente a sem alteração.</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="621"/>
        <source>Sync</source>
        <translation>Sync</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="646"/>
        <source> ms</source>
        <translation> ms</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="675"/>
        <source>Metadata</source>
        <translation>Metadados</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="728"/>
        <source>Reset</source>
        <translation>Repor</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="735"/>
        <source>Display a menu of additional actions</source>
        <translation>Exibir um menu de acções adicionais</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="777"/>
        <source>Show in Folder</source>
        <translation>Mostrar na Pasta</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="782"/>
        <source>Copy Full File Path</source>
        <translation>Copiar Atalho Completo do Ficheiro</translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="787"/>
        <source>More Information...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.ui" line="792"/>
        <source>Start Integrity Check Job</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="217"/>
        <location filename="../src/widgets/avformatproducerwidget.cpp" line="246"/>
        <source>None</source>
        <translation>Nenhum</translation>
    </message>
</context>
<context>
    <name>AvfoundationProducerWidget</name>
    <message>
        <location filename="../src/widgets/avfoundationproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../src/widgets/avfoundationproducerwidget.ui" line="26"/>
        <source>OS X A/V Device</source>
        <translation>Dispositivo A/V OS X </translation>
    </message>
    <message>
        <location filename="../src/widgets/avfoundationproducerwidget.ui" line="39"/>
        <location filename="../src/widgets/avfoundationproducerwidget.ui" line="48"/>
        <location filename="../src/widgets/avfoundationproducerwidget.cpp" line="59"/>
        <location filename="../src/widgets/avfoundationproducerwidget.cpp" line="60"/>
        <source>None</source>
        <translation>Nenhum</translation>
    </message>
    <message>
        <location filename="../src/widgets/avfoundationproducerwidget.ui" line="66"/>
        <source>Video Input</source>
        <translation>Entrada Vídeo</translation>
    </message>
    <message>
        <location filename="../src/widgets/avfoundationproducerwidget.ui" line="92"/>
        <source>Use this when you are going to capture Shotcut itself.
It makes the capture run in the background, but
you will not be able to simultaneously send
the screen capture to SDI/HDMI in this mode.</source>
        <translation>Use isto quando for capturar o próprio Shotcut.
Faz com que a captura seja executada em segundo
plano, mas, neste modo não terá a possibilidade de enviar
em simultâneo a captura de ecrã para SDI/HDMI</translation>
    </message>
    <message>
        <location filename="../src/widgets/avfoundationproducerwidget.ui" line="98"/>
        <source>Capture Shotcut</source>
        <translation>Capturar o Shotcut</translation>
    </message>
    <message>
        <location filename="../src/widgets/avfoundationproducerwidget.ui" line="56"/>
        <source>Audio Input</source>
        <translation>Entrada Áudio</translation>
    </message>
</context>
<context>
    <name>Clip</name>
    <message>
        <location filename="../src/qml/timeline/Clip.qml" line="569"/>
        <source>Cut</source>
        <translation type="unfinished">Cortar</translation>
    </message>
    <message>
        <location filename="../src/qml/timeline/Clip.qml" line="581"/>
        <source>Copy</source>
        <translation type="unfinished">Copiar</translation>
    </message>
    <message>
        <location filename="../src/qml/timeline/Clip.qml" line="588"/>
        <source>Remove</source>
        <translation>Remover</translation>
    </message>
    <message>
        <location filename="../src/qml/timeline/Clip.qml" line="593"/>
        <source>Lift</source>
        <translation>Levantar</translation>
    </message>
    <message>
        <location filename="../src/qml/timeline/Clip.qml" line="601"/>
        <source>Split At Playhead (S)</source>
        <translation>Dividir No Cursor (S)</translation>
    </message>
    <message>
        <location filename="../src/qml/timeline/Clip.qml" line="606"/>
        <source>Rebuild Audio Waveform</source>
        <translation>Reconstruir Forma de Onda Áudio</translation>
    </message>
</context>
<context>
    <name>ColorBarsWidget</name>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="26"/>
        <source>Color Bars</source>
        <translation>Barras de Cor</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="38"/>
        <source>Type</source>
        <translation>Tipo  </translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="55"/>
        <source>100% PAL color bars</source>
        <translation>Barras de Cor 100% PAL</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="60"/>
        <source>100% PAL color bars with red</source>
        <translation>Barras de Cor 100% PAL com vermelho</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="65"/>
        <source>95% BBC PAL color bars</source>
        <translation>Barras de Cor 95% BBC PAL</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="70"/>
        <source>75% EBU color bars</source>
        <translation>Barras de Cor 75% EBU</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="75"/>
        <source>SMPTE color bars</source>
        <translation>Barras de Cor SMPTE</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="80"/>
        <source>Philips PM5544</source>
        <translation>Philips PM5544</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="85"/>
        <source>FuBK</source>
        <translation>FuBK</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorbarswidget.ui" line="90"/>
        <source>Simplified FuBK</source>
        <translation>FuBK simplificado</translation>
    </message>
</context>
<context>
    <name>ColorPicker</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/ColorPicker.qml" line="56"/>
        <source>Click to open color dialog</source>
        <translation>Clique para abrir o diálogo de cores</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/ColorPicker.qml" line="61"/>
        <source>Please choose a color</source>
        <translation>Por favor escolha uma cor</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/ColorPicker.qml" line="80"/>
        <source>Pick a color on the screen. By pressing the mouse button and then moving your mouse you can select a section of the screen from which to get an average color.</source>
        <translation>Seleccione uma cor do ecrã. Prima o botão do rato e depois mova o rato para seleccionar uma secção do ecrã de onde obter uma cor média.</translation>
    </message>
</context>
<context>
    <name>ColorProducerWidget</name>
    <message>
        <location filename="../src/widgets/colorproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorproducerwidget.ui" line="26"/>
        <source>Color</source>
        <translation>Cor</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorproducerwidget.ui" line="41"/>
        <source>Color...</source>
        <translation>Cor...</translation>
    </message>
    <message>
        <location filename="../src/widgets/colorproducerwidget.ui" line="54"/>
        <source>#00000000</source>
        <translation>#00000000</translation>
    </message>
</context>
<context>
    <name>CustomProfileDialog</name>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="14"/>
        <source>Add Custom Video Mode</source>
        <translation>Adicionar Modo Vídeo Personalizado</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="29"/>
        <source>Colorspace</source>
        <translation>Espaço de Cores</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="76"/>
        <source>Resolution</source>
        <translation>Resolução</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="110"/>
        <source>:</source>
        <translation>:</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="145"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="167"/>
        <source>Interlaced</source>
        <translation>Entrelaçado</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="172"/>
        <source>Progressive</source>
        <translation>Progressivo</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="195"/>
        <source>Aspect ratio</source>
        <translation>Proporção</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="226"/>
        <source>x</source>
        <translation>x</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="261"/>
        <source>Frames/sec</source>
        <translation>Quadros/seg</translation>
    </message>
    <message>
        <location filename="../src/dialogs/customprofiledialog.ui" line="307"/>
        <source>Scan mode</source>
        <translation>Modo de varredura</translation>
    </message>
</context>
<context>
    <name>DecklinkProducerWidget</name>
    <message>
        <location filename="../src/widgets/decklinkproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../src/widgets/decklinkproducerwidget.ui" line="26"/>
        <source>SDI/HDMI</source>
        <translation>SDI/HDMI</translation>
    </message>
    <message>
        <location filename="../src/widgets/decklinkproducerwidget.ui" line="57"/>
        <source>Device</source>
        <translation>Dispositivo</translation>
    </message>
    <message>
        <location filename="../src/widgets/decklinkproducerwidget.ui" line="67"/>
        <source>Signal mode</source>
        <translation>Modo de sinal</translation>
    </message>
    <message>
        <location filename="../src/widgets/decklinkproducerwidget.ui" line="85"/>
        <source>Please be aware that not every card model supports automatic signal detection, and not all cards support all of the signal modes.</source>
        <translation>Por favor tenha em atenção que nem todos os modelos de placas suportam detecção automática de sinal e que nem todas as placas suportam todos os modos de sinal.</translation>
    </message>
    <message>
        <location filename="../src/widgets/decklinkproducerwidget.cpp" line="30"/>
        <source>Detect Automatically</source>
        <translation>Detectar Automaticamente</translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <location filename="../src/htmleditor/inserthtmldialog.ui" line="14"/>
        <source>Insert HTML</source>
        <translation>Inserir HTML</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/inserthtmldialog.ui" line="20"/>
        <source>HTML Code:</source>
        <translation>Código HTML:</translation>
    </message>
</context>
<context>
    <name>DirectShowVideoWidget</name>
    <message>
        <location filename="../src/widgets/directshowvideowidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../src/widgets/directshowvideowidget.ui" line="26"/>
        <source>DirectShow</source>
        <translation>DirectShow</translation>
    </message>
    <message>
        <location filename="../src/widgets/directshowvideowidget.ui" line="52"/>
        <location filename="../src/widgets/directshowvideowidget.ui" line="81"/>
        <source>None</source>
        <translation>Nenhum</translation>
    </message>
    <message>
        <location filename="../src/widgets/directshowvideowidget.ui" line="60"/>
        <source>Video Input</source>
        <translation>Entrada de Vídeo</translation>
    </message>
    <message>
        <location filename="../src/widgets/directshowvideowidget.ui" line="70"/>
        <source>Audio Input</source>
        <translation>Entrada de Áudio</translation>
    </message>
</context>
<context>
    <name>DurationDialog</name>
    <message>
        <location filename="../src/dialogs/durationdialog.ui" line="17"/>
        <source>Set Duration</source>
        <translation>Definir Duração</translation>
    </message>
    <message>
        <location filename="../src/dialogs/durationdialog.ui" line="25"/>
        <source>Duration</source>
        <translation>Duração</translation>
    </message>
</context>
<context>
    <name>EncodeDock</name>
    <message>
        <location filename="../src/docks/encodedock.ui" line="54"/>
        <source>search</source>
        <translation>procurar</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="85"/>
        <source>Add current settings as a new custom preset</source>
        <translation>Adicionar definições actuais como uma nova predefinição personalizada</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="99"/>
        <source>Delete currently selected preset</source>
        <translation>Eliminar predefinição actualmente seleccionada</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="175"/>
        <source>Format</source>
        <translation>Formato</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="241"/>
        <source>Video</source>
        <translation>Vídeo</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="441"/>
        <source>Resolution</source>
        <translation>Resolução</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="451"/>
        <source>Frames/sec</source>
        <translation>Quadros/seg</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="479"/>
        <source>:</source>
        <translation>:</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="520"/>
        <source>Bottom Field First</source>
        <translation>Campo Inferior Primeiro</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="525"/>
        <source>Top Field First</source>
        <translation>Campo Superior Primeiro</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="275"/>
        <source>Field order</source>
        <translation>Ordem dos campos</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="27"/>
        <source>Export</source>
        <translation>Exportar</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="165"/>
        <source>From</source>
        <translation>De</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="265"/>
        <source>Interpolation</source>
        <translation>Interpolação</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="285"/>
        <source>Aspect ratio</source>
        <translation>Proporção</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="313"/>
        <source>x</source>
        <translation>x</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="348"/>
        <source>Scan mode</source>
        <translation>Modo de varredura</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="367"/>
        <source>Interlaced</source>
        <translation>Entrelaçado</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="372"/>
        <source>Progressive</source>
        <translation>Progressivo</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="554"/>
        <source>One Field (fast)</source>
        <translation>One Field (rápido)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="559"/>
        <source>Linear Blend (fast)</source>
        <translation>Linear Blend (rápido)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="564"/>
        <source>YADIF - temporal only (good)</source>
        <translation>YADIF - apenas temporal (bom)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="569"/>
        <source>YADIF - temporal + spatial (best)</source>
        <translation>YADIF - temporal + espacial (melhor)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="592"/>
        <source>Deinterlacer</source>
        <translation>Desentrelaçador</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="608"/>
        <source>Nearest Neighbor (fast)</source>
        <translation>Nearest Neighbor (rápido)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="613"/>
        <source>Bilinear (good)</source>
        <translation>Bilinear (bom)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="618"/>
        <source>Bicubic (better)</source>
        <translation>Bicúbico (melhor)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="623"/>
        <source>Hyper/Lanczos (best)</source>
        <translation>Hyper/Lanczos (melhor)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="646"/>
        <source>This enables multiple image processing threads.
Sometimes, this can be a problem, and you can
test if turning this off helps. For example, some
interlaced AVCHD in conjunction with the YADIF
deinterlacer has been reported as problematic
with parallel processing enabled.</source>
        <translation>Isto permite vários segmentos de processamento de imagens
Por vezes, isso pode ser problemático e pode testar
desligando isto. Por exemplo, alguns AVCHD entrelaçados em
conjunto com o desentrelaçador YADIF foram relatados como
problemáticos com o processamento em paralelo activado.</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="654"/>
        <source>Parallel processing</source>
        <translation>Processamento paralelo</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="668"/>
        <location filename="../src/docks/encodedock.ui" line="677"/>
        <location filename="../src/docks/encodedock.ui" line="1270"/>
        <source>Codec</source>
        <translation>Codec</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="707"/>
        <source>GOP</source>
        <translation>GOP</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="719"/>
        <source>GOP = group of pictures, which is the maximum key frame interval</source>
        <translation>GOP= grupo de imagens, que é o intervalo máximo de key frames</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="732"/>
        <source>frames</source>
        <translation>quadros</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="756"/>
        <location filename="../src/docks/encodedock.ui" line="1312"/>
        <source>The average bit rate</source>
        <translation>Bitrato médio</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="766"/>
        <location filename="../src/docks/encodedock.ui" line="1337"/>
        <source>64k</source>
        <translation>64k</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="771"/>
        <location filename="../src/docks/encodedock.ui" line="1347"/>
        <source>128k</source>
        <translation>128k</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="776"/>
        <location filename="../src/docks/encodedock.ui" line="1357"/>
        <source>256k</source>
        <translation>256k</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="781"/>
        <location filename="../src/docks/encodedock.ui" line="1367"/>
        <source>512k</source>
        <translation>512k</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="786"/>
        <source>768k</source>
        <translation>768k</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="791"/>
        <location filename="../src/docks/encodedock.ui" line="1372"/>
        <source>1M</source>
        <translation>1M</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="796"/>
        <source>1200k</source>
        <translation>1200k</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="801"/>
        <source>1500k</source>
        <translation>1500k</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="806"/>
        <source>2M</source>
        <translation>2M</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="811"/>
        <source>2500k</source>
        <translation>2500k</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="816"/>
        <source>3M</source>
        <translation>3M</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="821"/>
        <source>4M</source>
        <translation>4M</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="826"/>
        <source>5M</source>
        <translation>5M</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="831"/>
        <source>6M</source>
        <translation>6M</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="836"/>
        <source>8M</source>
        <translation>8M</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="841"/>
        <source>10M</source>
        <translation>10M</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="846"/>
        <source>12M</source>
        <translation>12M</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="851"/>
        <source>14M</source>
        <translation>14M</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="856"/>
        <source>16M</source>
        <translation>16M</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="861"/>
        <source>18M</source>
        <translation>18M</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="866"/>
        <source>20M</source>
        <translation>20M</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="871"/>
        <source>25M</source>
        <translation>25M</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="876"/>
        <source>30M</source>
        <translation>30M</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="881"/>
        <source>40M</source>
        <translation>40M</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="886"/>
        <source>50M</source>
        <translation>50M</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="891"/>
        <source>60M</source>
        <translation>60M</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="896"/>
        <source>70M</source>
        <translation>70M</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="901"/>
        <source>80M</source>
        <translation>80M</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="909"/>
        <location filename="../src/docks/encodedock.ui" line="1380"/>
        <source>b/s</source>
        <translation>b/s</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="931"/>
        <source>Disable video</source>
        <translation>Desactivar Vídeo</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="938"/>
        <source>Dual pass</source>
        <translation>Passagem dupla</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="945"/>
        <source>B frames</source>
        <translation>Quadros B</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="957"/>
        <source>B frames are the bidirectional &quot;delta&quot; pictures
in temporal compression</source>
        <translation>Quadros B são imagens bidireccionais &quot;delta&quot; 
em compressão temporal</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="996"/>
        <source>Codec threads</source>
        <translation>Segmentos de Codec</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1011"/>
        <source>(0 = auto)</source>
        <translation>(0 = auto)</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1033"/>
        <location filename="../src/docks/encodedock.ui" line="1422"/>
        <source>Rate control</source>
        <translation>Controlo de frequência</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1046"/>
        <location filename="../src/docks/encodedock.ui" line="1435"/>
        <source>Average Bitrate</source>
        <translation>Bitrato Médio</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1051"/>
        <location filename="../src/docks/encodedock.ui" line="1440"/>
        <source>Constant Bitrate</source>
        <translation>Bitrato Constante</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1056"/>
        <location filename="../src/docks/encodedock.ui" line="1445"/>
        <source>Quality-based VBR</source>
        <translation>VBR baseado na Qualidade</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1079"/>
        <source>Buffer size</source>
        <translation>Tamanho do tampão</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1101"/>
        <source>KiB</source>
        <translation>KiB</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1123"/>
        <location filename="../src/docks/encodedock.ui" line="1468"/>
        <source>Quality</source>
        <translation>Qualidade</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1135"/>
        <location filename="../src/docks/encodedock.ui" line="1480"/>
        <source> %</source>
        <translation> %</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1166"/>
        <location filename="../src/docks/encodedock.ui" line="1300"/>
        <source>Bitrate</source>
        <translation>Bitrate</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1177"/>
        <source>Audio</source>
        <translation>Áudio</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1195"/>
        <source>8000</source>
        <translation>8000</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1200"/>
        <source>12000</source>
        <translation>12000</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1205"/>
        <source>16000</source>
        <translation>16000</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1210"/>
        <source>22050</source>
        <translation>22050</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1215"/>
        <source>32000</source>
        <translation>32000</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1220"/>
        <source>44100</source>
        <translation>44100</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1225"/>
        <source>48000</source>
        <translation>48000</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1230"/>
        <source>96000</source>
        <translation>96000</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1238"/>
        <source>Hz</source>
        <translation>Hz</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1260"/>
        <source>Sample rate</source>
        <translation>Taxa da Amostra</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1322"/>
        <source>16k</source>
        <translation>16k</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1327"/>
        <source>32k</source>
        <translation>32k</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1332"/>
        <source>48k</source>
        <translation>48k</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1342"/>
        <source>96k</source>
        <translation>96k</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1352"/>
        <source>220k</source>
        <translation>220k</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1362"/>
        <source>384k</source>
        <translation>384k</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1402"/>
        <source>Disable audio</source>
        <translation>Desactivar áudio</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1512"/>
        <source>Other</source>
        <translation>Outros</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1530"/>
        <location filename="../src/docks/encodedock.cpp" line="322"/>
        <location filename="../src/docks/encodedock.cpp" line="906"/>
        <source>Export File</source>
        <translation>Exportar Ficheiro</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1537"/>
        <location filename="../src/docks/encodedock.cpp" line="994"/>
        <location filename="../src/docks/encodedock.cpp" line="1001"/>
        <location filename="../src/docks/encodedock.cpp" line="1106"/>
        <source>Stream</source>
        <translation>Fluxo</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1544"/>
        <source>Reset options to defaults</source>
        <translation>Repor opções para valores padrão</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1547"/>
        <source>Reset</source>
        <translation>Repor</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.ui" line="1574"/>
        <source>Stop Screen Capture</source>
        <translation>Parar Captura de Ecrã</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="80"/>
        <source>Automatic from extension</source>
        <translation>Automático da extensão</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="88"/>
        <location filename="../src/docks/encodedock.cpp" line="95"/>
        <source>Default for format</source>
        <translation>Padrão para formato</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="324"/>
        <location filename="../src/docks/encodedock.cpp" line="888"/>
        <location filename="../src/docks/encodedock.cpp" line="906"/>
        <location filename="../src/docks/encodedock.cpp" line="1105"/>
        <source>Capture File</source>
        <translation>Capturar Ficheiro</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="329"/>
        <source>Timeline</source>
        <translation>Linha de Tempo</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="331"/>
        <source>Playlist</source>
        <translation>Lista de Reprodução</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="333"/>
        <source>Each Playlist Item</source>
        <translation>Qualquer Item da Lista de Reprodução</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="341"/>
        <location filename="../src/docks/encodedock.cpp" line="350"/>
        <source>Source</source>
        <translation>Origem</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="361"/>
        <location filename="../src/docks/encodedock.cpp" line="835"/>
        <source>Custom</source>
        <translation>Personalizado</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="373"/>
        <source>Stock</source>
        <translation>Valores</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="886"/>
        <location filename="../src/docks/encodedock.cpp" line="938"/>
        <source>Stop Capture</source>
        <translation>Parar Captura</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1041"/>
        <source>Add Export Preset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="989"/>
        <location filename="../src/docks/encodedock.cpp" line="1010"/>
        <source>Stop Stream</source>
        <translation>Parar Fluxo</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1002"/>
        <source>Enter the network protocol scheme, address, port, and parameters as an URL:</source>
        <translation>Introduzir como uma URL, o protocolo de rede, endereço, porta e parâmetros:</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1084"/>
        <source>Delete Preset</source>
        <translation>Eliminar Predefinição</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1085"/>
        <source>Are you sure you want to delete %1?</source>
        <translation>Tem a acerteza que pretende eliminar %1?</translation>
    </message>
    <message>
        <location filename="../src/docks/encodedock.cpp" line="1233"/>
        <source>KiB (%1s)</source>
        <translation>KiB (%1s)</translation>
    </message>
</context>
<context>
    <name>EncodeJob</name>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="37"/>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="38"/>
        <source>Open the output file in the Shotcut player</source>
        <translation>Abrir o ficheiro de saída no leitor do Shotcut</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="42"/>
        <location filename="../src/jobs/encodejob.cpp" line="43"/>
        <source>Show In Folder</source>
        <translation>Mostrar na Pasta</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="47"/>
        <source>Measure Video Quality...</source>
        <translation>Avaliar Qualidade Vídeo...</translation>
    </message>
    <message>
        <location filename="../src/jobs/encodejob.cpp" line="68"/>
        <source>Video Quality Report</source>
        <translation>Relatório de Qualidade Vídeo</translation>
    </message>
</context>
<context>
    <name>FfmpegJob</name>
    <message>
        <location filename="../src/jobs/ffmpegjob.cpp" line="36"/>
        <source>Open</source>
        <translation type="unfinished">Abrir</translation>
    </message>
    <message>
        <location filename="../src/jobs/ffmpegjob.cpp" line="40"/>
        <source>Check %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/jobs/ffmpegjob.cpp" line="66"/>
        <source>FFmpeg Log</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FfprobeJob</name>
    <message>
        <location filename="../src/jobs/ffprobejob.cpp" line="56"/>
        <source>More Information</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FilterController</name>
    <message>
        <location filename="../src/controllers/filtercontroller.cpp" line="175"/>
        <source>Only one %1 filter is allowed.</source>
        <translation>Só é permito um filtro %1.</translation>
    </message>
</context>
<context>
    <name>FilterMenu</name>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="107"/>
        <source>Show favorite filters</source>
        <translation>Mostrar filtros favoritos</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="122"/>
        <source>Show video filters</source>
        <translation>Mostrar filtros vídeo</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="137"/>
        <source>Show audio filters</source>
        <translation>Mostrar filtros áudio</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/FilterMenu.qml" line="154"/>
        <source>Close menu</source>
        <translation>Fechar menu</translation>
    </message>
</context>
<context>
    <name>FiltersDock</name>
    <message>
        <location filename="../src/docks/filtersdock.cpp" line="38"/>
        <source>Filters</source>
        <translation>Filtros</translation>
    </message>
</context>
<context>
    <name>GDIgrabWidget</name>
    <message>
        <location filename="../src/widgets/gdigrabwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../src/widgets/gdigrabwidget.ui" line="69"/>
        <source>Audio Input</source>
        <translation>Entrada Áudio</translation>
    </message>
    <message>
        <location filename="../src/widgets/gdigrabwidget.ui" line="138"/>
        <source>Resolution</source>
        <translation>Resolução</translation>
    </message>
    <message>
        <location filename="../src/widgets/gdigrabwidget.ui" line="79"/>
        <source>Width of the capture region</source>
        <translation>Largura da região de captura</translation>
    </message>
    <message>
        <location filename="../src/widgets/gdigrabwidget.ui" line="161"/>
        <source>The horizontal coordinate from the left edge when using a fixed capture region.</source>
        <translation>A coordenada horizontal a partir do lado esquerdo ao usar captura de região fixa.</translation>
    </message>
    <message>
        <location filename="../src/widgets/gdigrabwidget.ui" line="92"/>
        <source>Draw the mouse cursor</source>
        <translation>Desenhar com o cursor do rato</translation>
    </message>
    <message>
        <location filename="../src/widgets/gdigrabwidget.ui" line="105"/>
        <source>Choose an audio input method to use during capture.</source>
        <translation>Escolher método de entrada áudio a usar durante a captura.</translation>
    </message>
    <message>
        <location filename="../src/widgets/gdigrabwidget.ui" line="109"/>
        <source>None</source>
        <translation>Nenhum</translation>
    </message>
    <message>
        <location filename="../src/widgets/gdigrabwidget.ui" line="177"/>
        <source>x</source>
        <translation>x</translation>
    </message>
    <message>
        <location filename="../src/widgets/gdigrabwidget.ui" line="131"/>
        <source>Show the capture region</source>
        <translation>Mostrar a região de captura</translation>
    </message>
    <message>
        <location filename="../src/widgets/gdigrabwidget.ui" line="59"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../src/widgets/gdigrabwidget.ui" line="184"/>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <location filename="../src/widgets/gdigrabwidget.ui" line="117"/>
        <location filename="../src/widgets/gdigrabwidget.ui" line="191"/>
        <source>pixels</source>
        <translation>píxeis</translation>
    </message>
    <message>
        <location filename="../src/widgets/gdigrabwidget.ui" line="33"/>
        <source>The vertical coordinate from the top edge when using a fixed capture region.</source>
        <translation>A coordenada vertical a partir da parte superior ao usar captura de região fixa.</translation>
    </message>
    <message>
        <location filename="../src/widgets/gdigrabwidget.ui" line="148"/>
        <source>Height of the capture region</source>
        <translation>Altura da região de captura</translation>
    </message>
    <message>
        <location filename="../src/widgets/gdigrabwidget.ui" line="124"/>
        <source>Y</source>
        <translation>Y</translation>
    </message>
    <message>
        <location filename="../src/widgets/gdigrabwidget.ui" line="49"/>
        <source>Screen</source>
        <translation>Ecrã</translation>
    </message>
</context>
<context>
    <name>GLTestWidget</name>
    <message>
        <location filename="../src/widgets/gltestwidget.cpp" line="50"/>
        <source>Error:
This program requires OpenGL version 2.0
with the framebuffer object extension.</source>
        <translation>Erro:
Este programa requer o OpenGL version 2.0
com extensão de objecto framebuffer.</translation>
    </message>
</context>
<context>
    <name>HtmlEditor</name>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="14"/>
        <location filename="../src/htmleditor/htmleditor.cpp" line="158"/>
        <location filename="../src/htmleditor/htmleditor.cpp" line="739"/>
        <source>HTML Editor</source>
        <translation>Editor HTML</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="36"/>
        <source>&amp;Edit</source>
        <translation>&amp;Editar</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="52"/>
        <source>F&amp;ormat</source>
        <translation>F&amp;ormato</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="56"/>
        <source>St&amp;yle</source>
        <translation>Estilo</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="70"/>
        <source>&amp;Align</source>
        <translation>&amp;Alinhamento</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="101"/>
        <source>&amp;File</source>
        <translation>&amp;Ficheiro</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="115"/>
        <source>Standard</source>
        <translation>Padrão</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="181"/>
        <source>Tab 1</source>
        <translation>Separador 1</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="200"/>
        <source>about:blank</source>
        <translation>about:blank</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="209"/>
        <source>Tab 2</source>
        <translation>Separador 2</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="245"/>
        <source>&amp;New</source>
        <translation>&amp;Novo</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="254"/>
        <source>&amp;Open...</source>
        <translation>Abrir...</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="263"/>
        <source>&amp;Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="266"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="271"/>
        <source>Save &amp;As...</source>
        <translation>Guardar Como...</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="280"/>
        <source>&amp;Undo</source>
        <translation>An&amp;ular</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="283"/>
        <source>Ctrl+Z</source>
        <translation>Ctrl+Z</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="292"/>
        <source>&amp;Redo</source>
        <translation>&amp;Refazer</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="295"/>
        <source>Ctrl+Shift+Z</source>
        <translation>Ctrl+Shift+Z</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="304"/>
        <source>Cu&amp;t</source>
        <translation>Cor&amp;tar</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="307"/>
        <source>Ctrl+X</source>
        <translation>Ctrl+X</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="316"/>
        <source>&amp;Copy</source>
        <translation>&amp;Copiar</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="319"/>
        <source>Ctrl+C</source>
        <translation>Ctrl+C</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="328"/>
        <source>&amp;Paste</source>
        <translation>Colar</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="331"/>
        <source>Ctrl+V</source>
        <translation>Ctrl+V</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="340"/>
        <source>Select A&amp;ll</source>
        <translation>Seleccionar Tudo</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="343"/>
        <source>Ctrl+A</source>
        <translation>Ctrl+A</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="355"/>
        <source>&amp;Bold</source>
        <translation>Negrito</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="358"/>
        <source>Ctrl+B</source>
        <translation>Ctrl+B</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="370"/>
        <source>&amp;Italic</source>
        <translation>&amp;Itálico</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="373"/>
        <source>Ctrl+I</source>
        <translation>Ctrl+I</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="385"/>
        <source>&amp;Underline</source>
        <translation>S&amp;ublinhado</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="388"/>
        <source>Ctrl+U</source>
        <translation>Ctrl+U</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="400"/>
        <source>&amp;Strikethrough</source>
        <translation>Ri&amp;scado</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="409"/>
        <source>Align &amp;Left</source>
        <translation>Alinhar à Esquerda</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="418"/>
        <source>Align &amp;Center</source>
        <translation>Alinhar ao &amp;Centro</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="427"/>
        <source>Align &amp;Right</source>
        <translation>Alinhar à Di&amp;reita</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="436"/>
        <source>Align &amp;Justify</source>
        <translation>&amp;Justificar</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="445"/>
        <source>I&amp;ncrease Indent</source>
        <translation>Aumentar I&amp;ndentação</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="454"/>
        <source>&amp;Decrease Indent</source>
        <translation>Re&amp;duzir Indentação</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="466"/>
        <source>Bulle&amp;ted List</source>
        <translation>Lis&amp;ta com Símbolos</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="478"/>
        <source>&amp;Numbered List</source>
        <translation>Lista &amp;Numerada</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="487"/>
        <source>Insert &amp;Image...</source>
        <translation>Inserir &amp;Imagem</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="496"/>
        <source>Create Link...</source>
        <translation>Criar Ligação...</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="505"/>
        <source>Zoom Out</source>
        <translation>Reduzir</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="514"/>
        <source>Zoom In</source>
        <translation>Ampliar</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="523"/>
        <source>C&amp;lose Window</source>
        <translation>Fechar Jane&amp;la</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="526"/>
        <source>Close Window</source>
        <translation>Fechar Janela</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="529"/>
        <source>Ctrl+W</source>
        <translation>Ctrl+W</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="534"/>
        <source>&amp;Paragraph</source>
        <translation>&amp;Parágrafo</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="539"/>
        <source>Heading &amp;1</source>
        <translation>Título &amp;1</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="544"/>
        <source>Heading &amp;2</source>
        <translation>Título &amp;2</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="549"/>
        <source>Heading &amp;3</source>
        <translation>Título &amp;3</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="554"/>
        <source>Heading &amp;4</source>
        <translation>Título &amp;4</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="559"/>
        <source>Heading &amp;5</source>
        <translation>Título &amp;5</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="564"/>
        <source>Heading &amp;6</source>
        <translation>Título &amp;6</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="569"/>
        <source>Pre&amp;formatted</source>
        <translation>Pré&amp;formatado</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="574"/>
        <source>&amp;Address</source>
        <translation>Endereço</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="579"/>
        <source>&amp;Font Name...</source>
        <translation>Nome da &amp;Fonte...</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="584"/>
        <source>Text &amp;Color...</source>
        <translation>&amp;Cor do Texto...</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="589"/>
        <source>Bac&amp;kground Color...</source>
        <translation>Cor de Fundo...</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="597"/>
        <source>Font Si&amp;ze...</source>
        <translation>Estilo da Fonte...</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="606"/>
        <source>Insert HTML...</source>
        <translation>Inserir HTML...</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="609"/>
        <source>Insert HTML</source>
        <translation>Inserir HTML</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="617"/>
        <source>Text Outline...</source>
        <translation>Contorno do Texto...</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.ui" line="625"/>
        <source>Text Shadow...</source>
        <translation>Sombra do Texto...</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.cpp" line="62"/>
        <source>WYSIWYG Editor</source>
        <translation>Editor WYSWYG</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.cpp" line="63"/>
        <source>View Source</source>
        <translation>Ver Origem</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.cpp" line="159"/>
        <source>The document has been modified.
Do you want to save your changes?</source>
        <translation>O documento foi modificado.
Pretende guardar as alterações?</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.cpp" line="196"/>
        <source>Open File...</source>
        <translation>Abrir Ficheiro...</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.cpp" line="197"/>
        <location filename="../src/htmleditor/htmleditor.cpp" line="230"/>
        <source>HTML-Files (*.htm *.html);;All Files (*)</source>
        <translation>Ficheiros HTML (*.htm *.html);;Todos os Ficheiros (*)</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.cpp" line="229"/>
        <source>Save as...</source>
        <translation>Guardar como...</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.cpp" line="243"/>
        <source>Common Graphics (*.png *.jpg *.jpeg *.gif);;</source>
        <translation>Gráficos Comuns (*.png *.jpg *.jpeg *.gif);;</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.cpp" line="244"/>
        <source>Portable Network Graphics (PNG) (*.png);;</source>
        <translation>Portable Network Graphics (PNG) (*.png);;</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.cpp" line="245"/>
        <source>JPEG (*.jpg *.jpeg);;</source>
        <translation>JPEG (*.jpg *.jpeg);;</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.cpp" line="246"/>
        <source>Graphics Interchange Format (*.gif);;</source>
        <translation>Graphics Interchange Format (*.gif);;</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.cpp" line="247"/>
        <source>All Files (*)</source>
        <translation>Todos os Ficheiros (*)</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.cpp" line="249"/>
        <source>Open image...</source>
        <translation>Abrir imagem...</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.cpp" line="296"/>
        <source>Create link</source>
        <translation>Criar ligação</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.cpp" line="297"/>
        <source>Enter URL</source>
        <translation>Introduzir URL</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.cpp" line="487"/>
        <source>Font</source>
        <translation>Fonte</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.cpp" line="487"/>
        <source>Select font:</source>
        <translation>Seleccionar fonte:</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.cpp" line="497"/>
        <source>Font Size</source>
        <translation>Tamanho da Fonte</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.cpp" line="497"/>
        <source>Size in points:</source>
        <translation>Tamanho em pontos:</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.cpp" line="633"/>
        <source>Open %1 ?</source>
        <translation>Abrir %1 ?</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.cpp" line="634"/>
        <source>Open link</source>
        <translation>Abrir ligação</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.cpp" line="643"/>
        <source>Text Outline</source>
        <translation>Contorno do Texto</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.cpp" line="660"/>
        <source>Text Shadow</source>
        <translation>Sombra do Texto</translation>
    </message>
    <message>
        <location filename="../src/htmleditor/htmleditor.cpp" line="739"/>
        <source>%1[*] - %2</source>
        <translation>%1[*] - %2</translation>
    </message>
</context>
<context>
    <name>ImageProducerWidget</name>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="26"/>
        <source>TextLabel</source>
        <translation>Etiqueta de Texto</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="44"/>
        <source>Resolution</source>
        <translation>Resolução</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="78"/>
        <source>x</source>
        <translation>x</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="106"/>
        <source>Duration</source>
        <translation>Duração</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="116"/>
        <source>Pixel aspect ratio</source>
        <translation>Proporção de píxeis</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="147"/>
        <source>:</source>
        <translation>:</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="182"/>
        <source>Repeat</source>
        <translation>Repetir</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="200"/>
        <source> frames</source>
        <translation>quadros</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="216"/>
        <source>per picture</source>
        <translation>por imagem</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="175"/>
        <source>Image sequence</source>
        <translation>Sequência de imagens</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="255"/>
        <source>Make the current duration value the default value</source>
        <translation>Tornar o valor actual em valor padrão</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="258"/>
        <source>Set Default</source>
        <translation>Definir Padrão</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.ui" line="271"/>
        <source>Reset</source>
        <translation>Repor</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.cpp" line="186"/>
        <source>Getting length of image sequence...</source>
        <translation>A obter a duração da sequência de imagens...</translation>
    </message>
    <message>
        <location filename="../src/widgets/imageproducerwidget.cpp" line="194"/>
        <source>Reloading image sequence...</source>
        <translation>A recarregar a sequência de imagens...</translation>
    </message>
</context>
<context>
    <name>IsingWidget</name>
    <message>
        <location filename="../src/widgets/isingwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../src/widgets/isingwidget.ui" line="26"/>
        <source>Ising Model</source>
        <translation>Usar Modelo</translation>
    </message>
    <message>
        <location filename="../src/widgets/isingwidget.ui" line="41"/>
        <source>Noise Temperature</source>
        <translation>Temperatura do Ruído</translation>
    </message>
    <message>
        <location filename="../src/widgets/isingwidget.ui" line="106"/>
        <source>Border Growth</source>
        <translation>Crescimento dos Bordos</translation>
    </message>
    <message>
        <location filename="../src/widgets/isingwidget.ui" line="174"/>
        <source>Spontaneous Growth</source>
        <translation>Crescimento Espontâneo</translation>
    </message>
</context>
<context>
    <name>JackProducerWidget</name>
    <message>
        <location filename="../src/widgets/jackproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../src/widgets/jackproducerwidget.ui" line="26"/>
        <source>JACK Audio</source>
        <translation>Áudio JACK</translation>
    </message>
    <message>
        <location filename="../src/widgets/jackproducerwidget.ui" line="36"/>
        <source>You need to manually connect the JACK input ports.</source>
        <translation>Necessita ligar manualmente as portas de entrada JACK.</translation>
    </message>
</context>
<context>
    <name>JobQueue</name>
    <message>
        <location filename="../src/jobqueue.cpp" line="50"/>
        <source>pending</source>
        <translation>pendente</translation>
    </message>
    <message>
        <location filename="../src/jobqueue.cpp" line="77"/>
        <source>done</source>
        <translation>concluído</translation>
    </message>
    <message>
        <location filename="../src/jobqueue.cpp" line="79"/>
        <source>stopped</source>
        <translation>parado</translation>
    </message>
    <message>
        <location filename="../src/jobqueue.cpp" line="81"/>
        <source>failed</source>
        <translation>falhado</translation>
    </message>
</context>
<context>
    <name>JobsDock</name>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="18"/>
        <source>Jobs</source>
        <translation>Trabalhos</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="104"/>
        <source>Stop automatically processing the next pending job in
the list. This does not stop a currently running job. Right-
-click a job to open a menu to stop a currently running job.</source>
        <translation>Parar automaticamente o processamento da próximo trabalho
da lista. Isto não pára o trabalho actual. Clique-direito num
trabalho para abrir um menu para parar o trabalho actual.</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="109"/>
        <source>Pause</source>
        <translation>Pausar</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="119"/>
        <source>Remove all of the completed and failed jobs from the list</source>
        <translation>Remover todos os trabalhos concluídos e falhados da lista</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="122"/>
        <source>Clean</source>
        <translation>Limpar</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="129"/>
        <source>Display a menu of additional actions</source>
        <translation>Exibir um menu para acções adicionais</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="156"/>
        <source>Stop This Job</source>
        <translation>Parar este Trabalho</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="159"/>
        <source>Stop the currently selected job</source>
        <translation>Parar o trabalho actualmente seleccionado</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="164"/>
        <source>View Log</source>
        <translation>Ver Registo</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="167"/>
        <source>View the messages of MLT and FFmpeg </source>
        <translation>Ver as mensagens do MLT e FFmpeg</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="172"/>
        <source>Run</source>
        <translation>Executar</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="175"/>
        <source>Restart a stopped job</source>
        <translation>Reiniciar um trabalho parado</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.ui" line="180"/>
        <source>Remove</source>
        <translation type="unfinished">Remover</translation>
    </message>
    <message>
        <location filename="../src/docks/jobsdock.cpp" line="93"/>
        <source>Job Log</source>
        <translation>Registo do Trabalho</translation>
    </message>
</context>
<context>
    <name>LissajousWidget</name>
    <message>
        <location filename="../src/widgets/lissajouswidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../src/widgets/lissajouswidget.ui" line="26"/>
        <source>Lissajous</source>
        <translation>Lissajous</translation>
    </message>
    <message>
        <location filename="../src/widgets/lissajouswidget.ui" line="41"/>
        <source>X Ratio</source>
        <translation>Proporção X</translation>
    </message>
    <message>
        <location filename="../src/widgets/lissajouswidget.ui" line="106"/>
        <source>Y Ratio</source>
        <translation>Proporção Y</translation>
    </message>
</context>
<context>
    <name>LumaMixTransition</name>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="26"/>
        <source>Transition</source>
        <translation>Transição</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="232"/>
        <source>Change the softness of the edge of the wipe</source>
        <translation>Alterar a suavidade das bordas do corte</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="248"/>
        <location filename="../src/widgets/lumamixtransition.ui" line="334"/>
        <source> %</source>
        <translation> %</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="38"/>
        <source>Video</source>
        <translation>Vídeo</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="77"/>
        <source>Barn Door Horizontal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="207"/>
        <source>Swap the appearance of the A and B clips</source>
        <translation>Trocar a aparência dos clips A e B</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="210"/>
        <source>Invert Wipe</source>
        <translation>Inverter Troca</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="219"/>
        <location filename="../src/widgets/lumamixtransition.cpp" line="177"/>
        <location filename="../src/widgets/lumamixtransition.cpp" line="182"/>
        <location filename="../src/widgets/lumamixtransition.cpp" line="196"/>
        <source>Softness</source>
        <translation>Suavidade</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="294"/>
        <source>Do not alter the audio levels during the
course of the transition. Instead, set a
fixed mixing level, or choose only clip A&apos;s
audio (0%) or clip B&apos;s audio (100%).</source>
        <translation>Não altere os níveis áudio durante o
decorrer de uma transição. Defina um
nível de mistura fixo ou escolha apenas
o áudio do clip A (0%) ou do B (100%).</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="300"/>
        <source>Mix:</source>
        <translation>Mistura:</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="310"/>
        <source>A</source>
        <translation>A</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="327"/>
        <source>B</source>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="57"/>
        <source>Dissolve</source>
        <translation>Dissolver</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="62"/>
        <source>Cut</source>
        <translation>Cortar</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="67"/>
        <source>Bar Horizontal</source>
        <translation>Barra Horizontal</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="72"/>
        <source>Bar Vertical</source>
        <translation>Barra Vertical</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="82"/>
        <source>Barn Door Vertical</source>
        <translation>Porta Vertical</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="87"/>
        <source>Barn Door Diagonal SW-NE</source>
        <translation>Porta Diagonal SW-NE</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="92"/>
        <source>Barn Door Diagonal NW-SE</source>
        <translation>Porta Diagonal NW-SE</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="97"/>
        <source>Diagonal Top Left</source>
        <translation>Diagonal Superior Esquerda</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="102"/>
        <source>Diagonal Top Right</source>
        <translation>Diagonal Superior Direita</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="107"/>
        <source>Matrix Waterfall Horizontal</source>
        <translation>Matriz Cascata Horizontal</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="112"/>
        <source>Matrix Waterfall Vertical</source>
        <translation>Matriz Cascata Vertical</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="117"/>
        <source>Matrix Snake Horizontal</source>
        <translation>Matriz Cobra Horizontal</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="122"/>
        <source>Matrix Snake Parallel Horizontal</source>
        <translation>Matriz Cobra Paralela Horizontal</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="127"/>
        <source>Matrix Snake Vertical</source>
        <translation>Matriz Cobra Vertical</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="132"/>
        <source>Matrix Snake Parallel Vertical</source>
        <translation>Matriz Cobra Paralela Vertical</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="137"/>
        <source>Barn V Up</source>
        <translation>Porta V para cima</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="142"/>
        <source>Iris Circle</source>
        <translation>Círculo Iris</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="147"/>
        <source>Double Iris</source>
        <translation>Iris Dupla</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="152"/>
        <source>Iris Box</source>
        <translation>Caixa Iris</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="157"/>
        <source>Box Bottom Right</source>
        <translation>Caixa Inferior Direita</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="162"/>
        <source>Box Bottom Left</source>
        <translation>Caixa Inferior Esquerda</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="167"/>
        <source>Box Right Center</source>
        <translation>Caixa Centro Direita</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="172"/>
        <source>Clock Top</source>
        <translation>Relógio Superior</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="177"/>
        <source>Custom...</source>
        <translation>Personalizado...</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="275"/>
        <source>Automatically fade-out the audio of clip A
and fade-in the audio of clip B over the
duration of the transition.</source>
        <translation>Auto-desvanecer o áudio do clip A e
aumentar gradualmente o do B durante
a duração da transição.</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="280"/>
        <source>Cross-fade</source>
        <translation>Cross-fade</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="263"/>
        <source>Audio</source>
        <translation>Áudio</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.ui" line="200"/>
        <source>TextLabel</source>
        <translation>Etiqueta de Texto</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.cpp" line="48"/>
        <location filename="../src/widgets/lumamixtransition.cpp" line="179"/>
        <source>Position</source>
        <translation>Posição</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.cpp" line="188"/>
        <source>Open File</source>
        <translation>Abrir Ficheiro</translation>
    </message>
    <message>
        <location filename="../src/widgets/lumamixtransition.cpp" line="189"/>
        <source>Images (*.bmp *.jpeg *.jpg *.pgm *.png *.svg *.tga *.tif *.tiff);;All Files (*)</source>
        <translation>Imagens (*.bmp *.jpeg *.jpg *.pgm *.png *.svg *.tga *.tif *.tiff);;Todos os Ficheiros (*)</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="14"/>
        <source>Shotcut</source>
        <translation>Shotcut</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="47"/>
        <source>&amp;File</source>
        <translation>&amp;Ficheiro</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="64"/>
        <source>&amp;View</source>
        <translation>&amp;Ver</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="74"/>
        <source>&amp;Edit</source>
        <translation>&amp;Editar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="82"/>
        <source>&amp;Help</source>
        <translation>Ajuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="94"/>
        <source>Settings</source>
        <translation>Definições</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="98"/>
        <source>Deinterlacer</source>
        <translation>Desentrelaçador</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="107"/>
        <source>Interpolation</source>
        <translation>Interpolação</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="116"/>
        <source>Video Mode</source>
        <translation>Modo Vídeo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="122"/>
        <source>External Monitor</source>
        <translation>Monitor Externo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="128"/>
        <source>Language</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="133"/>
        <source>Theme</source>
        <translation>Tema</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="141"/>
        <source>Gamma</source>
        <translation>Gama</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="148"/>
        <source>Display Method</source>
        <translation>Método de Exibição</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="182"/>
        <source>Toolbar</source>
        <translation>Barra de Ferramentas</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="231"/>
        <source>&amp;Open File...</source>
        <translation>Abrir Ficheiro...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="234"/>
        <source>Open a video, audio or image file</source>
        <translation>Abre um ficheiro de vídeo, áudio ou imagem</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="237"/>
        <source>Ctrl+O</source>
        <translation>Ctrl+O</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="245"/>
        <source>E&amp;xit</source>
        <translation>Sair</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="248"/>
        <source>Quit the application</source>
        <translation>Encerra o programa</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="251"/>
        <source>Ctrl+Q</source>
        <translation>Ctrl+Q</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="256"/>
        <source>&amp;About Shotcut</source>
        <translation>&amp;Acerca do Shotcut</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="264"/>
        <source>About Qt</source>
        <translation>Acerca do Qt</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="272"/>
        <source>Open Other...</source>
        <translation>Abrir Outros...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="275"/>
        <source>Open a device, stream or generator</source>
        <translation>Abrir um dispositivo, fluxo ou gerador</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="278"/>
        <source>Ctrl+Shift+O</source>
        <translation>Ctrl+Shift+O</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="290"/>
        <source>&amp;Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="293"/>
        <source>Save project as a MLT XML file</source>
        <translation>Guarda projecto como um ficheiro MLT XML</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="296"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="304"/>
        <source>Save &amp;As...</source>
        <translation>Guardar Como...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="307"/>
        <source>Save project to a different MLT XML file</source>
        <translation>Guarda o projecto para um ficheiro MLT XML diferente</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="310"/>
        <source>Ctrl+Shift+S</source>
        <translation>Ctrl+Shift+S</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="319"/>
        <source>Export</source>
        <translation>Exportar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="322"/>
        <source>Show the Export panel</source>
        <translation>Mostrar Painel de Exportação</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="331"/>
        <source>&amp;Undo</source>
        <translation>An&amp;ular</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="340"/>
        <source>&amp;Redo</source>
        <translation>&amp;Refazer</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="345"/>
        <source>Forum...</source>
        <translation>Fórum...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="350"/>
        <source>FAQ...</source>
        <translation>Perguntas Mais Frequentes...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="359"/>
        <location filename="../src/mainwindow.cpp" line="2374"/>
        <source>Enter Full Screen</source>
        <translation>Entrar Ecrã Completo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="362"/>
        <source>Ctrl+Shift+F</source>
        <translation>Ctrl+Shift+F</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="371"/>
        <source>Peak Meter</source>
        <translation>Medidor de Picos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="374"/>
        <source>Show or hide the audio peak meter</source>
        <translation>Oculta ou mostra o medidor de picos áudio</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="383"/>
        <location filename="../src/mainwindow.cpp" line="232"/>
        <source>Properties</source>
        <translation>Propriedades</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="392"/>
        <source>Recent</source>
        <translation>Recentes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="401"/>
        <source>Playlist</source>
        <translation>Lista de Reprodução</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="410"/>
        <location filename="../src/mainwindow.cpp" line="318"/>
        <source>History</source>
        <translation>Histórico</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="419"/>
        <source>Full Screen</source>
        <translation>Ecrã Completo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="430"/>
        <source>Realtime (frame dropping)</source>
        <translation>Tempo Real (frame dropping)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="441"/>
        <source>Progressive</source>
        <translation>Progressivo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="449"/>
        <source>GPU Processing (experimental)</source>
        <translation>Processamento GPU (experimental)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="460"/>
        <source>One Field (fast)</source>
        <translation>Um Campo (rápido)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="468"/>
        <source>Linear Blend (fast)</source>
        <translation>Combinação Linear (rápido)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="476"/>
        <source>YADIF - temporal only (good)</source>
        <translation>YADIF - só temporal (bom)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="484"/>
        <source>YADIF - temporal + spatial (best)</source>
        <translation>YADIF - temporal + espacial (melhor)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="495"/>
        <source>Nearest Neighbor (fast)</source>
        <translation>Nearest Neighbor (rápido)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="503"/>
        <source>Bilinear (good)</source>
        <translation>Bilinear (bom)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="511"/>
        <source>Bicubic (better)</source>
        <translation>Bicúbico (melhor)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="519"/>
        <source>Hyper/Lanczos (best)</source>
        <translation>Hyper/Lanczos (melhor)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="530"/>
        <location filename="../src/mainwindow.ui" line="682"/>
        <source>Automatic</source>
        <translation>Automático</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="541"/>
        <source>None</source>
        <translation>Nenhum</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="549"/>
        <source>Use JACK Audio</source>
        <translation>Usar Áudio JACK</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="558"/>
        <source>Filters</source>
        <translation>Filtros</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="561"/>
        <source>Modify the video image or audio</source>
        <translation>Modificar a imagem vídeo ou o áudio</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="566"/>
        <source>Add...</source>
        <translation>Adicionar...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="574"/>
        <source>System</source>
        <translation>Sistema</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="577"/>
        <source>Use the user or platform style, colors, and icons.</source>
        <translation>Usar o estilo do utilizador ou da plataforma, cores e ícones.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="585"/>
        <source>Fusion Dark</source>
        <translation>Fusão Escura</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="593"/>
        <source>Fusion Light</source>
        <translation>Fusão Clara</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="598"/>
        <source>Tutorials...</source>
        <translation>Tutoriais...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="607"/>
        <source>Timeline</source>
        <translation>Linha de Tempo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="612"/>
        <location filename="../src/mainwindow.ui" line="615"/>
        <source>Restore Default Layout</source>
        <translation>Restaurar Esquema Padrão</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="631"/>
        <source>Show Toolbar</source>
        <translation>Mostrar Barra de Ferramentas</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="636"/>
        <source>Upgrade...</source>
        <translation>Actualizar...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="641"/>
        <source>Open MLT XML As Clip...</source>
        <translation>Abrir MLT XML Como Clip...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="644"/>
        <source>Open a MLT XML project file as a virtual clip</source>
        <translation>Abrir um ficheiro de projecto MLT XML como um clip virtual</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="655"/>
        <source>sRGB (computer)</source>
        <translation>sRGB (computador)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="663"/>
        <source>Rec. 709 (TV)</source>
        <translation>Rec. 709 (TV)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="671"/>
        <source>Scrub Audio</source>
        <translation>Clarificar Áudio</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="706"/>
        <source>Software (Mesa)</source>
        <extracomment>Do not translate &quot;Mesa&quot;</extracomment>
        <translation>Software (Mesa)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="711"/>
        <source>Application Log...</source>
        <translation>Registo do Programa...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="719"/>
        <source>Project</source>
        <translation>Projecto</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="727"/>
        <source>Player</source>
        <translation>Leitor</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="735"/>
        <source>User Interface</source>
        <translation>Interface do Utilizador</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="745"/>
        <source>Close</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="748"/>
        <source>Ctrl+W</source>
        <translation>Ctrl+W</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="763"/>
        <source>Cu&amp;t</source>
        <translation type="unfinished">Cor&amp;tar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="766"/>
        <source>Ctrl+X</source>
        <translation type="unfinished">Ctrl+X</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="778"/>
        <source>&amp;Copy</source>
        <translation type="unfinished">&amp;Copiar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="781"/>
        <source>Ctrl+C</source>
        <translation type="unfinished">Ctrl+C</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="793"/>
        <source>&amp;Paste</source>
        <translation type="unfinished">Colar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="796"/>
        <source>Ctrl+V</source>
        <translation type="unfinished">Ctrl+V</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="801"/>
        <source>Export EDL...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="806"/>
        <source>Export Frame...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="623"/>
        <source>Show Title Bars</source>
        <translation>Mostrar Barras de Títulos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="196"/>
        <source>Ctrl+Z</source>
        <translation>Ctrl+Z</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="197"/>
        <source>Ctrl+Shift+Z</source>
        <translation>Ctrl+Shift+Z</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="550"/>
        <source>Non-Broadcast</source>
        <translation>Sem-Transmissão</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="561"/>
        <source>DVD Widescreen NTSC</source>
        <translation>DVD Panorâmico NTSC</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="562"/>
        <source>DVD Widescreen PAL</source>
        <translation>DVD Panorâmico PAL</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="567"/>
        <source>Custom</source>
        <translation>Personalizado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="586"/>
        <source>Screen %1</source>
        <translation>Ecrã %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="617"/>
        <source>Off</source>
        <translation>Desligado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="620"/>
        <source>Internal</source>
        <translation>Interno</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="623"/>
        <source>External</source>
        <translation>Externo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="637"/>
        <source>DeckLink Keyer</source>
        <translation>Manipulador de DeckLink</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="799"/>
        <location filename="../src/mainwindow.cpp" line="801"/>
        <location filename="../src/mainwindow.cpp" line="1111"/>
        <location filename="../src/mainwindow.cpp" line="2851"/>
        <source>Failed to open </source>
        <translation>Falha ao abrir</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="827"/>
        <source>The file you opened uses GPU effects, but GPU processing is not enabled.
Do you want to enable GPU processing and restart?</source>
        <translation>O ficheiro que abriu usa efeitos GPU, mas o processamento não está activado.
Deseja activar o processamento GPU e reiniciar?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="885"/>
        <source>Shotcut noticed some problems in your project.
Do you want Shotcut to try to repair it?

If you choose Yes, Shotcut will create a copy of your project
with &quot;- Repaired&quot; in the file name and open it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="850"/>
        <source>Repaired</source>
        <translation>Reparado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="873"/>
        <source>Repairing the project failed.</source>
        <translation>Falha na reparação do projecto.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2589"/>
        <source>You must restart Shotcut to switch to the new language.
Do you want to restart now?</source>
        <translation>Tem que reiniciar o Shotcut para mudar de idioma.
Deseja reiniciar já?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2639"/>
        <source>You must restart Shotcut to switch using GPU processing.
Do you want to restart now?</source>
        <translation>Tem que reiniciar o Shotcut para usar o processamento GPU.
Deseja reiniciar já?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2892"/>
        <source>You must restart Shotcut to change the display method.
Do you want to restart now?</source>
        <translation>Tem que reiniciar o Shotcut para alterar o método de exibição.
Deseja reiniciar agora?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2914"/>
        <source>Application Log</source>
        <translation>Registo do Programa</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="921"/>
        <source>Auto-saved files exist. Do you want to recover them now?</source>
        <translation>Existem ficheiros guardados automaticamente. Quer recuperá-los agora?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="119"/>
        <source>Error: This program requires the JACK 1 library.

Please install it using your package manager. It may be named libjack0, jack-audio-connection-kit, jack, or similar.</source>
        <translation>Erro: Este programa necessita da biblioteca JACK 1.

Instale-a usando o seu gestor de pacotes. Ela deve chamar-se libjack0, jack-audio-connection-kit, jack, ou semelhante.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="127"/>
        <source>Error: This program requires the SDL 1.2 library.

Please install it using your package manager. It may be named libsdl1.2debian, SDL, or similar.</source>
        <translation>Erro: Este programa necessita da biblioteca SDL 1.2.

Instale-a usando o seu gestor de pacotes.  Ela pode ter o nome de libsdl1.2debian, SDL, ou semelhante.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1122"/>
        <location filename="../src/mainwindow.cpp" line="2831"/>
        <source>Open File</source>
        <translation>Abrir Ficheiro</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1345"/>
        <source>%1[*] - %2</source>
        <translation>%1[*] - %2</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1350"/>
        <source>About Shotcut</source>
        <translation>Acerca do Shotcut</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1351"/>
        <source>&lt;h1&gt;Shotcut version %1&lt;/h1&gt;&lt;p&gt;&lt;a href=&quot;https://www.shotcut.org/&quot;&gt;Shotcut&lt;/a&gt; is a free, open source, cross platform video editor.&lt;/p&gt;&lt;small&gt;&lt;p&gt;Copyright &amp;copy; 2011-2016 &lt;a href=&quot;https://www.meltytech.com/&quot;&gt;Meltytech&lt;/a&gt;, LLC&lt;/p&gt;&lt;p&gt;Licensed under the &lt;a href=&quot;http://www.gnu.org/licenses/gpl.html&quot;&gt;GNU General Public License v3.0&lt;/a&gt;&lt;/p&gt;&lt;p&gt;This program proudly uses the following projects:&lt;ul&gt;&lt;li&gt;&lt;a href=&quot;http://www.qt-project.org/&quot;&gt;Qt&lt;/a&gt; application and UI framework&lt;/li&gt;&lt;li&gt;&lt;a href=&quot;http://www.mltframework.org/&quot;&gt;MLT&lt;/a&gt; multimedia authoring framework&lt;/li&gt;&lt;li&gt;&lt;a href=&quot;http://www.ffmpeg.org/&quot;&gt;FFmpeg&lt;/a&gt; multimedia format and codec libraries&lt;/li&gt;&lt;li&gt;&lt;a href=&quot;http://www.videolan.org/developers/x264.html&quot;&gt;x264&lt;/a&gt; H.264 encoder&lt;/li&gt;&lt;li&gt;&lt;a href=&quot;http://www.webmproject.org/&quot;&gt;WebM&lt;/a&gt; VP8 and VP9 encoders&lt;/li&gt;&lt;li&gt;&lt;a href=&quot;http://lame.sourceforge.net/&quot;&gt;LAME&lt;/a&gt; MP3 encoder&lt;/li&gt;&lt;li&gt;&lt;a href=&quot;http://www.dyne.org/software/frei0r/&quot;&gt;Frei0r&lt;/a&gt; video plugins&lt;/li&gt;&lt;li&gt;&lt;a href=&quot;http://www.ladspa.org/&quot;&gt;LADSPA&lt;/a&gt; audio plugins&lt;/li&gt;&lt;li&gt;&lt;a href=&quot;http://www.defaulticon.com/&quot;&gt;DefaultIcon&lt;/a&gt; icon collection by &lt;a href=&quot;http://www.interactivemania.com/&quot;&gt;interactivemania&lt;/a&gt;&lt;/li&gt;&lt;li&gt;&lt;a href=&quot;http://www.oxygen-icons.org/&quot;&gt;Oxygen&lt;/a&gt; icon collection&lt;/li&gt;&lt;/ul&gt;&lt;/p&gt;&lt;p&gt;The source code used to build this program can be downloaded from &lt;a href=&quot;https://www.shotcut.org/&quot;&gt;shotcut.org&lt;/a&gt;.&lt;/p&gt;This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.&lt;/small&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1839"/>
        <source>Click here to check for a new version of Shotcut.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1918"/>
        <location filename="../src/mainwindow.cpp" line="1945"/>
        <source>Saved %1</source>
        <translation>Guardado %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1928"/>
        <source>Save XML</source>
        <translation>Guardar XML</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1928"/>
        <source>MLT XML (*.mlt)</source>
        <translation>MLT XML (*.mlt)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1937"/>
        <source>Unable to save empty file, but saved its name for future.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1957"/>
        <source>The project has been modified.
Do you want to save your changes?</source>
        <translation>O projecto foi modificado.
Quer guardar as suas alterações?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1984"/>
        <source>There are incomplete jobs.
Do you want to still want to exit?</source>
        <translation>Existem trabalhos incompletos.
Mesmo assim deseja sair?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2377"/>
        <source>Exit Full Screen</source>
        <translation>Sair de Ecrã Completo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2390"/>
        <source>GPU Processing is not supported</source>
        <translation>O Processamento GPU não é suportado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2630"/>
        <source>Failed to connect to JACK.
Please verify that JACK is installed and running.</source>
        <translation>Falha ao ligar ao JACK.
Verifique se o JACK está instalado e em execução.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2832"/>
        <source>MLT XML (*.mlt);;All Files (*)</source>
        <translation>MLT XML (*.mlt);;Todos os Ficheiros (*)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2948"/>
        <source>Shotcut version %1 is available! Click here to get it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2952"/>
        <source>You are running the latest version of Shotcut.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2962"/>
        <source>Failed to read version.json when checking. Click here to go to the Web site.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3012"/>
        <source>Export EDL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3012"/>
        <source>EDL (*.edl)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3053"/>
        <source>A JavaScript error occurred during export.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3056"/>
        <source>Failed to open export-edl.js</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3082"/>
        <source>Export Frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3092"/>
        <source>Unable to export frame.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MeltJob</name>
    <message>
        <location filename="../src/jobs/meltjob.cpp" line="37"/>
        <source>View XML</source>
        <translation>Ver XML</translation>
    </message>
    <message>
        <location filename="../src/jobs/meltjob.cpp" line="38"/>
        <source>View the MLT XML for this job</source>
        <translation>Ver o MLT XML para este trabalho</translation>
    </message>
    <message>
        <location filename="../src/jobs/meltjob.cpp" line="91"/>
        <source>MLT XML</source>
        <translation>MLT XML</translation>
    </message>
</context>
<context>
    <name>MeltedClipsModel</name>
    <message>
        <location filename="../src/mvcp/meltedclipsmodel.cpp" line="92"/>
        <source>%1 GiB</source>
        <translation>%1 GiB</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedclipsmodel.cpp" line="95"/>
        <source>%1 MiB</source>
        <translation>%1 MiB</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedclipsmodel.cpp" line="98"/>
        <source>%1 KiB</source>
        <translation>%1 KiB</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedclipsmodel.cpp" line="99"/>
        <source>%1 B</source>
        <translation>%1 B</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedclipsmodel.cpp" line="102"/>
        <source>item</source>
        <translation>item</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedclipsmodel.cpp" line="102"/>
        <source>items</source>
        <translation>itens</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedclipsmodel.cpp" line="117"/>
        <source>Clip</source>
        <translation>Clip</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedclipsmodel.cpp" line="117"/>
        <source>Size</source>
        <translation>Tamanho</translation>
    </message>
</context>
<context>
    <name>MeltedPlaylistDock</name>
    <message>
        <location filename="../src/mvcp/meltedplaylistdock.ui" line="18"/>
        <source>Melted Playlist</source>
        <translation>Lista de Reprodução Melted</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedplaylistdock.ui" line="67"/>
        <source>Add something to the playlist</source>
        <translation>Adicione algo à lista de reprodução</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedplaylistdock.ui" line="84"/>
        <source>Remove cut</source>
        <translation>Remover corte</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedplaylistdock.ui" line="98"/>
        <source>Display a menu of additional actions</source>
        <translation>Exibir um menu para acções adicionais</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedplaylistdock.ui" line="128"/>
        <source>Insert Cut</source>
        <translation>Inserir Corte</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedplaylistdock.ui" line="137"/>
        <source>Append Cut</source>
        <translation>Anexar Corte</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedplaylistdock.ui" line="142"/>
        <source>Open As Clip</source>
        <translation>Abrir Como Clip</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedplaylistdock.ui" line="145"/>
        <source>Open the cut in the player</source>
        <translation>Abrir o corte no leitor</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedplaylistdock.ui" line="150"/>
        <source>Remove</source>
        <translation>Remover</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedplaylistdock.ui" line="155"/>
        <source>Goto</source>
        <translation>Ir para</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedplaylistdock.ui" line="158"/>
        <source>Go to the start of this cut in the playlist</source>
        <translation>Ir para o início deste corte na lista de reprodução</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedplaylistdock.ui" line="163"/>
        <source>Remove All</source>
        <translation>Remover Tudo</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedplaylistdock.ui" line="166"/>
        <source>Remove all items from the playlist</source>
        <translation>Remove todos os itens da lista de reprodução</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedplaylistdock.ui" line="171"/>
        <source>Wipe</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedplaylistdock.ui" line="174"/>
        <source>Remove all items before the currently playing clip</source>
        <translation>Remove todos os itens antes do clip em reprodução</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedplaylistdock.ui" line="179"/>
        <source>Clean</source>
        <translation>Limpar</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedplaylistdock.ui" line="182"/>
        <source>Remove all items except the currently playing clip</source>
        <translation>Remove todos os itens excepto o clip em reprodução</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedplaylistdock.cpp" line="198"/>
        <location filename="../src/mvcp/meltedplaylistdock.cpp" line="215"/>
        <source>&quot;Remove All&quot; will remove all of clips in the playlist.

IMPORTANT: You cannot Undo this action!

Do you want to continue?</source>
        <translation>&quot;Remover Tudo&quot; irá remover todos os clips da lista.

IMPORTANTE: Não pode anular esta acção!

Pretende continuar?</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedplaylistdock.cpp" line="232"/>
        <source>&quot;Clean&quot; will remove all of clips in the playlist
except the currently playing clip.

IMPORTANT: You cannot Undo this action!

Do you want to continue?</source>
        <translation>&quot;Limpar&quot; irá remover todos os clips da lista de reprodução
excepto o actualmente em reprodução.

IMPORTANTE: Não pode Anular esta acção!

Pretende continuar?</translation>
    </message>
</context>
<context>
    <name>MeltedPlaylistModel</name>
    <message>
        <location filename="../src/mvcp/meltedplaylistmodel.cpp" line="112"/>
        <source>#</source>
        <translation>#</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedplaylistmodel.cpp" line="114"/>
        <source>Clip</source>
        <translation>Clip</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedplaylistmodel.cpp" line="116"/>
        <source>In</source>
        <translation>Entrada</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedplaylistmodel.cpp" line="118"/>
        <source>Out</source>
        <translation>Saída</translation>
    </message>
</context>
<context>
    <name>MeltedServerDock</name>
    <message>
        <location filename="../src/mvcp/meltedserverdock.ui" line="18"/>
        <source>Melted Server</source>
        <translation>Servidor Melted</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedserverdock.ui" line="52"/>
        <source>Enter the server address and press Enter</source>
        <translation>Introduza o endereço do servidor e prima Enter</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedserverdock.ui" line="59"/>
        <location filename="../src/mvcp/meltedserverdock.cpp" line="160"/>
        <source>Connect</source>
        <translation>Ligar</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedserverdock.ui" line="93"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Single-click&lt;/span&gt; a unit to open its playlist.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Double-click&lt;/span&gt; a unit to control it in the player, or &lt;span style=&quot; font-weight:600;&quot;&gt;right-click&lt;/span&gt; the unit for transport control actions.&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Single-click&lt;/span&gt; a playlist item to select it for edit operations (e.g. Insert).&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Double-click&lt;/span&gt; a playlist item to seek the unit to it.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Drag-n-drop&lt;/span&gt; from the server&apos;s clips tree to the playlist, or &lt;span style=&quot; font-weight:600;&quot;&gt;single-click&lt;/span&gt; a clip to select it for use with &lt;span style=&quot; font-weight:600;&quot;&gt;Add&lt;/span&gt; and &lt;span style=&quot; font-weight:600;&quot;&gt;Insert&lt;/span&gt; actions.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Clique numa&lt;/span&gt; unidade para abrir a sua lista de reprodução.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Duplo-clique&lt;/span&gt; numa unidade para controlá-la no leitor, ou &lt;span style=&quot; font-weight:600;&quot;&gt;clique-direito&lt;/span&gt; na unidade para acções de controlo de transporte.&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Clique&lt;/span&gt; num item da lista de reprodução para seleccioná-lo para edição (p.e. Inserir).&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Duplo-clique&lt;/span&gt; num item da lista de reprodução para procurar a sua unidade.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Arraste-e-largue&lt;/span&gt; da árvore de clips para a lista de reprodução, ou &lt;span style=&quot; font-weight:600;&quot;&gt;clique&lt;/span&gt; num clip para o seleccionar para uso com &lt;span style=&quot; font-weight:600;&quot;&gt;Acções de&lt;/span&gt; Adicionar e &lt;span style=&quot; font-weight:600;&quot;&gt;Inserir&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedserverdock.ui" line="195"/>
        <source>Console</source>
        <translation>Consola</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedserverdock.ui" line="208"/>
        <source>Display a menu of additional actions</source>
        <translation>Exibir um menu para acções adicionais</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedserverdock.ui" line="238"/>
        <source>Play</source>
        <translation>Reproduzir</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedserverdock.ui" line="243"/>
        <source>Pause</source>
        <translation>Pausar</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedserverdock.ui" line="248"/>
        <source>Stop</source>
        <translation>Parar</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedserverdock.ui" line="253"/>
        <source>Rewind</source>
        <translation>Rebobinar</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedserverdock.ui" line="258"/>
        <source>Fast Forward</source>
        <translation>Avanço Rápido</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedserverdock.ui" line="263"/>
        <source>Map Clips Root</source>
        <translation>Mapear Raiz dos Clips</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedserverdock.cpp" line="152"/>
        <source>Disconnect</source>
        <translation>Desligar</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedserverdock.cpp" line="257"/>
        <source>Choose Directory</source>
        <translation>Escolher Pasta</translation>
    </message>
</context>
<context>
    <name>MeltedUnitsModel</name>
    <message>
        <location filename="../src/mvcp/meltedunitsmodel.cpp" line="70"/>
        <source>Unit</source>
        <translation>Unidade</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedunitsmodel.cpp" line="70"/>
        <source>Status</source>
        <translation>Estado</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedunitsmodel.cpp" line="111"/>
        <source>unknown</source>
        <translation>desconhecido</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedunitsmodel.cpp" line="112"/>
        <source>undefined</source>
        <translation>indefinido</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedunitsmodel.cpp" line="113"/>
        <source>offline</source>
        <translation>desligado</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedunitsmodel.cpp" line="114"/>
        <source>unloaded</source>
        <translation>não carregado</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedunitsmodel.cpp" line="115"/>
        <source>stopped</source>
        <translation>parado</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedunitsmodel.cpp" line="116"/>
        <source>playing</source>
        <translation>a reproduzir</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedunitsmodel.cpp" line="117"/>
        <source>paused</source>
        <translation>pausado</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedunitsmodel.cpp" line="118"/>
        <source>disconnected</source>
        <translation>desligado</translation>
    </message>
</context>
<context>
    <name>MvcpThread</name>
    <message>
        <location filename="../src/mvcp/mvcpthread.cpp" line="165"/>
        <source>unknown</source>
        <translation>desconhecido</translation>
    </message>
    <message>
        <location filename="../src/mvcp/mvcpthread.cpp" line="166"/>
        <source>undefined</source>
        <translation>indefinido</translation>
    </message>
    <message>
        <location filename="../src/mvcp/mvcpthread.cpp" line="167"/>
        <source>offline</source>
        <translation>desligado</translation>
    </message>
    <message>
        <location filename="../src/mvcp/mvcpthread.cpp" line="168"/>
        <source>unloaded</source>
        <translation>não carregado</translation>
    </message>
    <message>
        <location filename="../src/mvcp/mvcpthread.cpp" line="169"/>
        <source>stopped</source>
        <translation>parado</translation>
    </message>
    <message>
        <location filename="../src/mvcp/mvcpthread.cpp" line="170"/>
        <source>playing</source>
        <translation>a reproduzir</translation>
    </message>
    <message>
        <location filename="../src/mvcp/mvcpthread.cpp" line="171"/>
        <source>paused</source>
        <translation>pausado</translation>
    </message>
    <message>
        <location filename="../src/mvcp/mvcpthread.cpp" line="172"/>
        <source>disconnected</source>
        <translation>desligado</translation>
    </message>
</context>
<context>
    <name>NetworkProducerWidget</name>
    <message>
        <location filename="../src/widgets/networkproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../src/widgets/networkproducerwidget.ui" line="26"/>
        <source>Network Stream</source>
        <translation>Fluxo de Rede</translation>
    </message>
    <message>
        <location filename="../src/widgets/networkproducerwidget.ui" line="41"/>
        <source>&amp;URL</source>
        <translation>&amp;URL</translation>
    </message>
    <message>
        <location filename="../src/widgets/networkproducerwidget.ui" line="57"/>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
</context>
<context>
    <name>NoiseWidget</name>
    <message>
        <location filename="../src/widgets/noisewidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../src/widgets/noisewidget.ui" line="26"/>
        <source>Noise</source>
        <translation>Ruído</translation>
    </message>
</context>
<context>
    <name>OpenOtherDialog</name>
    <message>
        <location filename="../src/openotherdialog.ui" line="17"/>
        <source>Open Other</source>
        <translation>Abrir Outro</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.ui" line="43"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="32"/>
        <location filename="../src/openotherdialog.cpp" line="130"/>
        <source>Network</source>
        <translation>Rede</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="37"/>
        <source>Device</source>
        <translation>Dispositivo</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="39"/>
        <location filename="../src/openotherdialog.cpp" line="132"/>
        <source>SDI/HDMI</source>
        <translation>SDI/HDMI</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="43"/>
        <location filename="../src/openotherdialog.cpp" line="118"/>
        <source>Video4Linux</source>
        <translation>Video4Linux</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="45"/>
        <location filename="../src/openotherdialog.cpp" line="120"/>
        <source>PulseAudio</source>
        <translation>PulseAudio</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="47"/>
        <location filename="../src/openotherdialog.cpp" line="122"/>
        <source>JACK Audio</source>
        <translation>JACK Áudio</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="49"/>
        <location filename="../src/openotherdialog.cpp" line="124"/>
        <source>ALSA Audio</source>
        <translation>Áudio ASLA</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="51"/>
        <location filename="../src/openotherdialog.cpp" line="56"/>
        <location filename="../src/openotherdialog.cpp" line="128"/>
        <source>Screen</source>
        <translation>Ecrã</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="54"/>
        <location filename="../src/openotherdialog.cpp" line="126"/>
        <source>DirectShow</source>
        <translation>DirectShow</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="59"/>
        <source>OS X A/V Device</source>
        <translation>Dispositivo A/V OS X</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="64"/>
        <source>Generator</source>
        <translation>Gerador</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="66"/>
        <location filename="../src/openotherdialog.cpp" line="134"/>
        <source>Color</source>
        <translation>Cor</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="70"/>
        <location filename="../src/openotherdialog.cpp" line="136"/>
        <source>Noise</source>
        <translation>Ruído</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="74"/>
        <location filename="../src/openotherdialog.cpp" line="138"/>
        <source>Ising</source>
        <translation>Ising</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="78"/>
        <location filename="../src/openotherdialog.cpp" line="140"/>
        <source>Lissajous</source>
        <translation>Lissajous</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="82"/>
        <location filename="../src/openotherdialog.cpp" line="142"/>
        <source>Plasma</source>
        <translation>Plasma</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="86"/>
        <location filename="../src/openotherdialog.cpp" line="144"/>
        <source>Color Bars</source>
        <translation>Barras de Cor</translation>
    </message>
    <message>
        <location filename="../src/openotherdialog.cpp" line="90"/>
        <location filename="../src/openotherdialog.cpp" line="146"/>
        <source>Audio Tone</source>
        <translation>Tonalidade Áudio</translation>
    </message>
</context>
<context>
    <name>PlasmaWidget</name>
    <message>
        <location filename="../src/widgets/plasmawidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../src/widgets/plasmawidget.ui" line="26"/>
        <source>Plasma</source>
        <translation>Plasma</translation>
    </message>
    <message>
        <location filename="../src/widgets/plasmawidget.ui" line="41"/>
        <source>Speed 1</source>
        <translation>Velocidade 1</translation>
    </message>
    <message>
        <location filename="../src/widgets/plasmawidget.ui" line="112"/>
        <source>Speed 2</source>
        <translation>Velocidade 2</translation>
    </message>
    <message>
        <location filename="../src/widgets/plasmawidget.ui" line="180"/>
        <source>Speed 3</source>
        <translation>Velocidade 3</translation>
    </message>
    <message>
        <location filename="../src/widgets/plasmawidget.ui" line="252"/>
        <source>Speed 4</source>
        <translation>Velocidade 4</translation>
    </message>
    <message>
        <location filename="../src/widgets/plasmawidget.ui" line="323"/>
        <source>Move 1</source>
        <translation>Movimento 1</translation>
    </message>
    <message>
        <location filename="../src/widgets/plasmawidget.ui" line="391"/>
        <source>Move 2</source>
        <translation>Movimento 2</translation>
    </message>
</context>
<context>
    <name>Player</name>
    <message>
        <location filename="../src/player.cpp" line="58"/>
        <source>Source</source>
        <translation>Origem</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="59"/>
        <source>Project</source>
        <translation>Projecto</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="139"/>
        <source>Adjust the audio volume</source>
        <translation>Ajustar o volume áudio</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="158"/>
        <source>Silence the audio</source>
        <translation>Silenciar áudio</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="177"/>
        <source>Transport Controls</source>
        <translation>Controlos de Transporte</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="184"/>
        <source>Current position</source>
        <translation>Posição Actual</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="188"/>
        <source>Total Duration</source>
        <translation>Duração Total</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="193"/>
        <source>In Point</source>
        <translation>Ponto de entrada</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="197"/>
        <source>Selected Duration</source>
        <translation>Duração Seleccionada</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="213"/>
        <source>Zoom Fit</source>
        <translation>Ajustar ampliação</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="222"/>
        <source>Zoom 100%</source>
        <translation>Ampliação 100%</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="219"/>
        <source>Zoom 50%</source>
        <translation>Ampliação 50%</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="216"/>
        <source>Zoom 25%</source>
        <translation type="unfinished">Ampliação 200% {25%?}</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="225"/>
        <source>Zoom 200%</source>
        <translation>Ampliação 200%</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="230"/>
        <source>Toggle zoom</source>
        <translation>Alternar ampliação</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="315"/>
        <location filename="../src/player.cpp" line="410"/>
        <location filename="../src/player.cpp" line="433"/>
        <location filename="../src/player.cpp" line="573"/>
        <location filename="../src/player.cpp" line="684"/>
        <source>Play</source>
        <translation>Reproduzir</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="317"/>
        <location filename="../src/player.cpp" line="411"/>
        <location filename="../src/player.cpp" line="434"/>
        <location filename="../src/player.cpp" line="574"/>
        <location filename="../src/player.cpp" line="685"/>
        <source>Start playback (L)</source>
        <translation>Iniciar reprodução (L)</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="320"/>
        <location filename="../src/player.cpp" line="390"/>
        <location filename="../src/player.cpp" line="568"/>
        <location filename="../src/player.cpp" line="691"/>
        <source>Pause</source>
        <translation>Pausar</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="322"/>
        <location filename="../src/player.cpp" line="391"/>
        <location filename="../src/player.cpp" line="569"/>
        <location filename="../src/player.cpp" line="692"/>
        <source>Pause playback (K)</source>
        <translation>Pausar reprodução (K)</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="324"/>
        <source>Skip Next</source>
        <translation>Saltar para o Próximo</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="326"/>
        <source>Skip to the next point (Alt+Right)</source>
        <translation>Saltar para o próximo ponto (Alt+Direita)</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="329"/>
        <source>Skip Previous</source>
        <translation>Saltar para o Anterior</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="331"/>
        <source>Skip to the previous point (Alt+Left)</source>
        <translation>Saltar para o ponto anterior (Alt+Esquerda)</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="334"/>
        <source>Rewind</source>
        <translation>Rebobinar</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="336"/>
        <source>Play quickly backwards (J)</source>
        <translation>Reproduzir rápido para trás (J)</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="338"/>
        <source>Fast Forward</source>
        <translation>Avanço Rápido</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="340"/>
        <source>Play quickly forwards (L)</source>
        <translation>Reproduzir rápido para a frente (L)</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="342"/>
        <source>Volume</source>
        <translation>Volume</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="344"/>
        <source>Show the volume control</source>
        <translation>Mostrar controlo do volume</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="395"/>
        <source>Stop</source>
        <translation>Parar</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="396"/>
        <source>Stop playback (K)</source>
        <translation>Parar reprodução (K)</translation>
    </message>
    <message>
        <location filename="../src/player.cpp" line="461"/>
        <source>Live</source>
        <translation>Ao vivo</translation>
    </message>
</context>
<context>
    <name>PlaylistDock</name>
    <message>
        <location filename="../src/docks/playlistdock.ui" line="18"/>
        <source>Playlist</source>
        <translation>Lista de Reprodução</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.ui" line="129"/>
        <source>Add something to the playlist</source>
        <translation>Adicione algo à lista de reprodução</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.ui" line="146"/>
        <source>Remove cut</source>
        <translation>Remover corte</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.ui" line="180"/>
        <source>Display a menu of additional actions</source>
        <translation>Exibir um menu para acções adicionais</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.ui" line="210"/>
        <source>Insert Cut</source>
        <translation>Inserir Corte</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.ui" line="220"/>
        <source>Append Cut</source>
        <translation>Anexar Corte</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.ui" line="225"/>
        <source>Insert Blank</source>
        <translation>Inserir em Banco</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.ui" line="230"/>
        <source>Append Blank</source>
        <translation>Anexar em Branco</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.ui" line="163"/>
        <source>Update</source>
        <translation>Actualizar</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.ui" line="59"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:16px; margin-left:-24px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Double-click&lt;/span&gt; a playlist item to open it in the player.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:16px; margin-left:-24px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;You can freely preview clips without necessarily adding them to the playlist or closing it.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:16px; margin-left:-24px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;To trim or adjust a playlist item &lt;span style=&quot; font-weight:600;&quot;&gt;Double-click&lt;/span&gt; to open it, make the changes, and click the &lt;span style=&quot; font-weight:600;&quot;&gt;Update&lt;/span&gt; icon.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:16px; margin-left:-24px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Drag-n-drop&lt;/span&gt; to rearrange the items.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:16px; margin-left:-24px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Duplo-clique&lt;/span&gt; num item da lista de reprodução para o abrir no leitor.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:16px; margin-left:-24px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Pode pré-visualizar clips sem ter que adicioná-los à lista de reprodução ou fechá-la.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:16px; margin-left:-24px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Para aparar ou ajustar um  item da lista&lt;span style=&quot; font-weight:600;&quot;&gt;Duplo-clique&lt;/span&gt; para abri-lo, fazer as alterações, e clicar no ícone &lt;span style=&quot; font-weight:600;&quot;&gt;Actualizar&lt;/span&gt;.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:16px; margin-left:-24px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Arrastar-e-largar&lt;/span&gt; para reorganizar os itens.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.ui" line="92"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Double-click a playlist item to open it in the player.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Duplo-clique num item da lista de reprodução para abri-lo no leitor.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.ui" line="235"/>
        <source>Replace</source>
        <translation>Substituir</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.ui" line="240"/>
        <source>Open As Clip</source>
        <translation>Abrir Como Clip</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.ui" line="243"/>
        <source>Open the cut in the player</source>
        <translation>Abrir o corte no leitor</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.ui" line="248"/>
        <source>Remove</source>
        <translation>Remover</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.ui" line="253"/>
        <source>Goto</source>
        <translation>Ir para</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.ui" line="256"/>
        <source>Go to the start of this cut in the playlist</source>
        <translation>Ir para o início deste corte na lista de reprodução</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.ui" line="261"/>
        <source>Remove All</source>
        <translation>Remover Tudo</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.ui" line="264"/>
        <source>Remove all items from the playlist</source>
        <translation>Remover todos os itens da lista de reprodução</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.ui" line="272"/>
        <source>Hidden</source>
        <translation>Oculto</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.ui" line="280"/>
        <location filename="../src/docks/playlistdock.ui" line="283"/>
        <source>In and Out - Left/Right</source>
        <translation>Entrada e Saída - Esquerda/Direita</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.ui" line="291"/>
        <location filename="../src/docks/playlistdock.ui" line="294"/>
        <source>In and Out - Top/Bottom</source>
        <translation>Entrada e Saída - Cima/Baixo</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.ui" line="302"/>
        <source>In Only - Small</source>
        <translation>Só Entrada - Pequena</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.ui" line="310"/>
        <source>In Only - Large</source>
        <translation>Só Entrada - Grande</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.ui" line="315"/>
        <source>Add All to Timeline</source>
        <translation>Adicionar Tudo à Linha de Tempos</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="154"/>
        <source>Thumbnails</source>
        <translation>Miniaturas</translation>
    </message>
    <message>
        <location filename="../src/docks/playlistdock.cpp" line="179"/>
        <location filename="../src/docks/playlistdock.cpp" line="246"/>
        <location filename="../src/docks/playlistdock.cpp" line="401"/>
        <source>You cannot insert a playlist into a playlist!</source>
        <translation>Não pode inserir uma lista de reprodução dentro de outra!</translation>
    </message>
</context>
<context>
    <name>PlaylistModel</name>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="299"/>
        <source>#</source>
        <translation>#</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="301"/>
        <source>Thumbnails</source>
        <translation>Miniaturas</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="303"/>
        <source>Clip</source>
        <translation>Clip</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="305"/>
        <source>In</source>
        <translation>Entrada</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="307"/>
        <source>Duration</source>
        <translation>Duração</translation>
    </message>
    <message>
        <location filename="../src/models/playlistmodel.cpp" line="309"/>
        <source>Start</source>
        <translation>Iniciar</translation>
    </message>
</context>
<context>
    <name>Preset</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="49"/>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="58"/>
        <source>Delete</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="70"/>
        <source>Save Preset</source>
        <translation>Guardar Predefinição</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="84"/>
        <source>Name:</source>
        <translation>Nome:</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="106"/>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="141"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="111"/>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="152"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="123"/>
        <source>Delete Preset</source>
        <translation>Eliminar Predefinição</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/Preset.qml" line="132"/>
        <source>Are you sure you want to delete %1?</source>
        <translation>Tema acerteza que pretende eliminar %1?</translation>
    </message>
</context>
<context>
    <name>PulseAudioWidget</name>
    <message>
        <location filename="../src/widgets/pulseaudiowidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../src/widgets/pulseaudiowidget.ui" line="26"/>
        <source>PulseAudio</source>
        <translation>PulseAudio</translation>
    </message>
</context>
<context>
    <name>QConsole</name>
    <message>
        <location filename="../src/mvcp/qconsole.cpp" line="757"/>
        <source>Undo</source>
        <translation>Anular</translation>
    </message>
    <message>
        <location filename="../src/mvcp/qconsole.cpp" line="758"/>
        <source>Ctrl+Z</source>
        <translation>Ctrl+Z</translation>
    </message>
    <message>
        <location filename="../src/mvcp/qconsole.cpp" line="759"/>
        <source>Redo</source>
        <translation>Refazer</translation>
    </message>
    <message>
        <location filename="../src/mvcp/qconsole.cpp" line="760"/>
        <source>Ctrl+Y</source>
        <translation>Ctrl+Y</translation>
    </message>
    <message>
        <location filename="../src/mvcp/qconsole.cpp" line="761"/>
        <source>Cut</source>
        <translation>Cortar</translation>
    </message>
    <message>
        <location filename="../src/mvcp/qconsole.cpp" line="762"/>
        <source>Ctrl+X</source>
        <translation>Ctrl+X</translation>
    </message>
    <message>
        <location filename="../src/mvcp/qconsole.cpp" line="763"/>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <location filename="../src/mvcp/qconsole.cpp" line="764"/>
        <source>Ctrl+Ins</source>
        <translation>Ctrl+Ins</translation>
    </message>
    <message>
        <location filename="../src/mvcp/qconsole.cpp" line="765"/>
        <source>Paste</source>
        <translation>Colar</translation>
    </message>
    <message>
        <location filename="../src/mvcp/qconsole.cpp" line="766"/>
        <source>Ctrl+V</source>
        <translation>Ctrl+V</translation>
    </message>
    <message>
        <location filename="../src/mvcp/qconsole.cpp" line="767"/>
        <source>Delete</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <location filename="../src/mvcp/qconsole.cpp" line="768"/>
        <source>Del</source>
        <translation>Del</translation>
    </message>
    <message>
        <location filename="../src/mvcp/qconsole.cpp" line="769"/>
        <source>Select All</source>
        <translation>Seleccionar Tudo</translation>
    </message>
    <message>
        <location filename="../src/mvcp/qconsole.cpp" line="770"/>
        <source>Ctrl+A</source>
        <translation>Ctrl+A</translation>
    </message>
    <message>
        <location filename="../src/mvcp/qconsole.cpp" line="835"/>
        <source>:\</source>
        <translation>:\</translation>
    </message>
    <message>
        <location filename="../src/mvcp/qconsole.cpp" line="837"/>
        <source>/</source>
        <translation>/</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="32"/>
        <source>Append playlist item %1</source>
        <translation>Anexar o item %1 da lista de reprodução</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="54"/>
        <source>Insert playist item %1</source>
        <translation>Inserir o item %1 da lista de reprodução</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="76"/>
        <source>Update playlist item %1</source>
        <translation>Actualizar o item %1 da lista de reprodução</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="100"/>
        <source>Remove playlist item %1</source>
        <translation>Remover o item %1 da lista de reprodução</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="121"/>
        <source>Clear playlist</source>
        <translation>Limpar lista de reprodução</translation>
    </message>
    <message>
        <location filename="../src/commands/playlistcommands.cpp" line="149"/>
        <source>Move item from %1 to %2</source>
        <translation>Mover o item %1 para %2</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedplaylistdock.cpp" line="317"/>
        <source>Append %1</source>
        <translation>Anexar %1</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedplaylistdock.cpp" line="343"/>
        <source>Remove %1 at %2</source>
        <translation>Remover %1 em %2</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedplaylistdock.cpp" line="369"/>
        <source>Insert %1 at %2</source>
        <translation>Inserir %1 em %2</translation>
    </message>
    <message>
        <location filename="../src/mvcp/meltedplaylistdock.cpp" line="393"/>
        <source>Move %1 from %2 to %3</source>
        <translation>Mover %1 de %2 para %3</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="34"/>
        <source>Append to track</source>
        <translation>Anexar à faixa</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="62"/>
        <source>Insert into track</source>
        <translation>Inserir na faixa</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="89"/>
        <source>Overwrite onto track</source>
        <translation>Sobrescrever na faixa</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="116"/>
        <source>Lift from track</source>
        <translation>Elevar da faixa</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="142"/>
        <source>Remove from track</source>
        <translation>Remover da faixa</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="168"/>
        <source>Change track name</source>
        <translation>Mudar o nome da faixa</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="189"/>
        <source>Toggle track mute</source>
        <translation>Alternar faixa silenciada</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="210"/>
        <source>Toggle track hidden</source>
        <translation>Alternar faixa oculta</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="232"/>
        <source>Change track compositing</source>
        <translation>Alterar composição da faixa</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="254"/>
        <source>Lock track</source>
        <translation>Bloquear faixa</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="281"/>
        <source>Move clip</source>
        <translation>Mover clip</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="307"/>
        <source>Trim clip in point</source>
        <translation>Ponto de entrada do recorte do clip</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="354"/>
        <source>Trim clip out point</source>
        <translation>Ponto de saída do recorte do clip</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="399"/>
        <source>Split clip</source>
        <translation>Dividir clip</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="423"/>
        <source>Adjust fade in</source>
        <translation>Ajustar aumento gradual</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="455"/>
        <source>Adjust fade out</source>
        <translation>Ajustar desvanecimento</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="486"/>
        <location filename="../src/commands/timelinecommands.cpp" line="612"/>
        <location filename="../src/commands/timelinecommands.cpp" line="725"/>
        <source>Add transition</source>
        <translation>Adicionar transição</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="525"/>
        <source>Trim transition in point</source>
        <translation>Ponto de entrada de recorte da transição</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="568"/>
        <source>Trim transition out point</source>
        <translation>Ponto de saída de recorte da transição</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="654"/>
        <location filename="../src/commands/timelinecommands.cpp" line="689"/>
        <source>Remove transition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="763"/>
        <source>Add video track</source>
        <translation>Adicionar faixa de vídeo</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="765"/>
        <source>Add audio track</source>
        <translation>Adicionar faixa de áudio</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="790"/>
        <source>Insert audio track</source>
        <translation>Inserir faixa de áudio</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="792"/>
        <source>Insert video track</source>
        <translation>Inserir faixa de vídeo</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="814"/>
        <source>Remove audio track</source>
        <translation>Remover faixa de áudio</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="816"/>
        <source>Remove video track</source>
        <translation>Remover faixa de vídeo</translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="863"/>
        <source>Change track blend mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/commands/timelinecommands.cpp" line="897"/>
        <source>Change clip properties</source>
        <translation>Alterar propriedades do clip</translation>
    </message>
    <message>
        <location filename="../src/mltxmlchecker.cpp" line="92"/>
        <source>The file is not a MLT XML file.</source>
        <translation>O ficheiro não é MLT XML.</translation>
    </message>
</context>
<context>
    <name>QmlFilter</name>
    <message>
        <location filename="../src/qmltypes/qmlfilter.cpp" line="165"/>
        <source>(defaults)</source>
        <translation>(padrões)</translation>
    </message>
    <message>
        <location filename="../src/qmltypes/qmlfilter.cpp" line="228"/>
        <source>Analyze %1</source>
        <translation>Analizar %1</translation>
    </message>
</context>
<context>
    <name>RecentDock</name>
    <message>
        <location filename="../src/docks/recentdock.ui" line="24"/>
        <source>Recent</source>
        <translation>Recentes</translation>
    </message>
    <message>
        <location filename="../src/docks/recentdock.ui" line="46"/>
        <source>Show only files with name matching text</source>
        <translation>Mostrar apenas ficheiros com nome coincidente</translation>
    </message>
    <message>
        <location filename="../src/docks/recentdock.ui" line="49"/>
        <source>search</source>
        <translation>procurar</translation>
    </message>
</context>
<context>
    <name>SaveDefaultButton</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/SaveDefaultButton.qml" line="24"/>
        <source>Set as default</source>
        <translation>Definir como padrão</translation>
    </message>
</context>
<context>
    <name>ScopeController</name>
    <message>
        <location filename="../src/controllers/scopecontroller.cpp" line="34"/>
        <source>Scopes</source>
        <translation>Âmbitos</translation>
    </message>
</context>
<context>
    <name>ServicePresetWidget</name>
    <message>
        <location filename="../src/widgets/servicepresetwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../src/widgets/servicepresetwidget.ui" line="25"/>
        <source>Preset</source>
        <translation>Predefinição</translation>
    </message>
    <message>
        <location filename="../src/widgets/servicepresetwidget.ui" line="45"/>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <location filename="../src/widgets/servicepresetwidget.ui" line="52"/>
        <source>Delete</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <location filename="../src/widgets/servicepresetwidget.cpp" line="76"/>
        <source>(defaults)</source>
        <translation>(padrões)</translation>
    </message>
    <message>
        <location filename="../src/widgets/servicepresetwidget.cpp" line="83"/>
        <source>Save Preset</source>
        <translation>Guardar Predefinição</translation>
    </message>
    <message>
        <location filename="../src/widgets/servicepresetwidget.cpp" line="84"/>
        <source>Name:</source>
        <translation>Nome:</translation>
    </message>
    <message>
        <location filename="../src/widgets/servicepresetwidget.cpp" line="135"/>
        <source>Delete Preset</source>
        <translation>Eliminar Predefinição</translation>
    </message>
    <message>
        <location filename="../src/widgets/servicepresetwidget.cpp" line="136"/>
        <source>Are you sure you want to delete %1?</source>
        <translation>Tema acerteza que pretende eliminar %1?</translation>
    </message>
</context>
<context>
    <name>SimplePropertyUI</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/SimplePropertyUI.qml" line="14"/>
        <source>Custom Properties</source>
        <translation>Propriedades Personalizadas</translation>
    </message>
</context>
<context>
    <name>SizePositionUI</name>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="43"/>
        <source>Bottom Left</source>
        <translation>Inferior Esquerda</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="48"/>
        <source>Bottom Right</source>
        <translation>Inferior Direita</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="53"/>
        <source>Top Left</source>
        <translation>Superior Esquerda</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="58"/>
        <source>Top Right</source>
        <translation>Superior Direita</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="122"/>
        <source>Preset</source>
        <translation>Predefinição</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="133"/>
        <source>Position</source>
        <translation>Posição</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="153"/>
        <source>Size</source>
        <translation>Tamanho</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="174"/>
        <source>Size mode</source>
        <translation>Modo Tamanho</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="181"/>
        <source>Fit</source>
        <translation>Ajustar</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="190"/>
        <source>Fill</source>
        <translation>Preencher</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="199"/>
        <source>Distort</source>
        <translation>Distorcer</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="209"/>
        <source>Horizontal fit</source>
        <translation>Ajuste horizontal</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="214"/>
        <source>Left</source>
        <translation>Esquerda</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="221"/>
        <source>Center</source>
        <translation>Centro</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="228"/>
        <source>Right</source>
        <translation>Direita</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="236"/>
        <source>Vertical fit</source>
        <translation>Ajuste vertical</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="241"/>
        <source>Top</source>
        <translation>Superior</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="248"/>
        <source>Middle</source>
        <translation>Meio</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/SizePositionUI.qml" line="255"/>
        <source>Bottom</source>
        <translation>Inferior</translation>
    </message>
</context>
<context>
    <name>TextViewerDialog</name>
    <message>
        <location filename="../src/dialogs/textviewerdialog.ui" line="17"/>
        <source>Dialog</source>
        <translation>Diálogo</translation>
    </message>
    <message>
        <location filename="../src/dialogs/textviewerdialog.cpp" line="45"/>
        <source>Save Text</source>
        <translation>Guardar Texto</translation>
    </message>
</context>
<context>
    <name>TimeSpinner</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TimeSpinner.qml" line="47"/>
        <source>Decrement</source>
        <translation>Decréscimo</translation>
    </message>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/TimeSpinner.qml" line="68"/>
        <source>Increment</source>
        <translation>Incremento</translation>
    </message>
</context>
<context>
    <name>TimelineDock</name>
    <message>
        <location filename="../src/docks/timelinedock.ui" line="33"/>
        <source>Timeline</source>
        <translation>Linha de Tempo</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="158"/>
        <source>This track is locked</source>
        <translation>Esta faixa está bloqueada</translation>
    </message>
    <message>
        <location filename="../src/docks/timelinedock.cpp" line="816"/>
        <source>You cannot split a transition.</source>
        <translation>Não pode dividir uma transição.</translation>
    </message>
</context>
<context>
    <name>TimelinePropertiesWidget</name>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="26"/>
        <source>Timeline</source>
        <translation>Linha de Tempo</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="39"/>
        <source>Frame rate</source>
        <translation>Taxa de Quadros</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="49"/>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="138"/>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="155"/>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="172"/>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="237"/>
        <source>:</source>
        <translation>:</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="56"/>
        <source>Resolution</source>
        <translation>Resolução</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="145"/>
        <source>Scan mode</source>
        <translation>Modo de análise</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="162"/>
        <source>Aspect ratio</source>
        <translation>Proporção</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.ui" line="203"/>
        <source>Colorspace</source>
        <translation>Espaço de cor</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.cpp" line="35"/>
        <source>%L1 fps</source>
        <translation>%L1 qps</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.cpp" line="37"/>
        <source>Progressive</source>
        <translation>Progressivo</translation>
    </message>
    <message>
        <location filename="../src/widgets/timelinepropertieswidget.cpp" line="39"/>
        <source>Interlaced</source>
        <translation>Entrelaçado</translation>
    </message>
</context>
<context>
    <name>TimelineToolbar</name>
    <message>
        <location filename="../src/qml/timeline/TimelineToolbar.qml" line="105"/>
        <source>Toggle snapping</source>
        <translation>Activar ajustes</translation>
    </message>
    <message>
        <location filename="../src/qml/timeline/TimelineToolbar.qml" line="114"/>
        <source>Scrub while dragging</source>
        <translation>Limpar ao arrastar</translation>
    </message>
    <message>
        <location filename="../src/qml/timeline/TimelineToolbar.qml" line="123"/>
        <source>Ripple trim and drop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/timeline/TimelineToolbar.qml" line="124"/>
        <source>Ripple</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/timeline/TimelineToolbar.qml" line="154"/>
        <source>Display a menu of additional actions</source>
        <translation>Exibir um menu para acções adicionais</translation>
    </message>
    <message>
        <location filename="../src/qml/timeline/TimelineToolbar.qml" line="162"/>
        <source>Cut - Copy the current clip to the Source
player and ripple delete it</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/timeline/TimelineToolbar.qml" line="171"/>
        <source>Copy - Copy the current clip to the Source player (C)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/timeline/TimelineToolbar.qml" line="180"/>
        <source>Paste - Insert clip into the current track
shifting following clips to the right (V)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/timeline/TimelineToolbar.qml" line="188"/>
        <source>Append to the current track (A)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/timeline/TimelineToolbar.qml" line="196"/>
        <source>Ripple Delete - Remove current clip
shifting following clips to the left (X)</source>
        <translation>Eliminação Intercalada - Remove o clip actual
deslocando os seguintes para a esquerda (X)</translation>
    </message>
    <message>
        <location filename="../src/qml/timeline/TimelineToolbar.qml" line="204"/>
        <source>Lift - Remove current clip without
affecting position of other clips (Z)</source>
        <translation>Alçar - Remove o clip actual sem
afectar a posição dos outros (Z)</translation>
    </message>
    <message>
        <location filename="../src/qml/timeline/TimelineToolbar.qml" line="212"/>
        <source>Overwrite clip onto the current track (B)</source>
        <translation>Sobrescreve o clip na faixa actual (B)</translation>
    </message>
    <message>
        <location filename="../src/qml/timeline/TimelineToolbar.qml" line="220"/>
        <source>Split At Playhead (S)</source>
        <translation>Dividir No Cursor (S)</translation>
    </message>
</context>
<context>
    <name>ToneProducerWidget</name>
    <message>
        <location filename="../src/widgets/toneproducerwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../src/widgets/toneproducerwidget.ui" line="26"/>
        <source>Audio Tone</source>
        <translation>Tonalidade Áudio</translation>
    </message>
    <message>
        <location filename="../src/widgets/toneproducerwidget.ui" line="41"/>
        <source>Frequency</source>
        <translation>Frequência</translation>
    </message>
    <message>
        <location filename="../src/widgets/toneproducerwidget.ui" line="51"/>
        <source> Hz</source>
        <translation> Hz</translation>
    </message>
    <message>
        <location filename="../src/widgets/toneproducerwidget.ui" line="90"/>
        <source> dB</source>
        <translation> dB</translation>
    </message>
    <message>
        <location filename="../src/widgets/toneproducerwidget.ui" line="80"/>
        <source>Level</source>
        <translation>Nível</translation>
    </message>
    <message>
        <location filename="../src/widgets/toneproducerwidget.cpp" line="97"/>
        <source>Tone: %1Hz %2dB</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TrackHead</name>
    <message>
        <location filename="../src/qml/timeline/TrackHead.qml" line="152"/>
        <source>M</source>
        <comment>Mute</comment>
        <translation>M</translation>
    </message>
    <message>
        <location filename="../src/qml/timeline/TrackHead.qml" line="158"/>
        <source>Mute</source>
        <translation>Sem som</translation>
    </message>
    <message>
        <location filename="../src/qml/timeline/TrackHead.qml" line="177"/>
        <source>H</source>
        <comment>Hide</comment>
        <translation>O</translation>
    </message>
    <message>
        <location filename="../src/qml/timeline/TrackHead.qml" line="183"/>
        <source>Hide</source>
        <translation>Ocultar</translation>
    </message>
    <message>
        <location filename="../src/qml/timeline/TrackHead.qml" line="202"/>
        <source>C</source>
        <comment>Composite</comment>
        <translation>C</translation>
    </message>
    <message>
        <location filename="../src/qml/timeline/TrackHead.qml" line="226"/>
        <source>L</source>
        <comment>Lock</comment>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../src/qml/timeline/TrackHead.qml" line="249"/>
        <source>Lock track</source>
        <translation>Bloquear faixa</translation>
    </message>
    <message>
        <location filename="../src/qml/timeline/TrackHead.qml" line="208"/>
        <source>Composite</source>
        <translation>Composto</translation>
    </message>
</context>
<context>
    <name>TrackPropertiesWidget</name>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.ui" line="38"/>
        <source>Blend mode</source>
        <translation>Modo de Mistura</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="37"/>
        <source>Track: %1</source>
        <translation>Faixa: %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="44"/>
        <source>Over</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="45"/>
        <source>Add</source>
        <translation>Adicionar</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="46"/>
        <source>Saturate</source>
        <translation>Saturar</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="47"/>
        <source>Multiply</source>
        <translation>Multiplicar</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="48"/>
        <source>Screen</source>
        <translation>Ecrã</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="49"/>
        <source>Overlay</source>
        <translation>Sobreposição</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="50"/>
        <source>Darken</source>
        <translation>Escurecer</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="51"/>
        <source>Dodge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="52"/>
        <source>Burn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="53"/>
        <source>Hard Light</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="54"/>
        <source>Soft Light</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="55"/>
        <source>Difference</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="56"/>
        <source>Exclusion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="57"/>
        <source>HSL Hue</source>
        <translation>Matiz HSL</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="58"/>
        <source>HSL Saturation</source>
        <translation>Saturação HSL</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="59"/>
        <source>HSL Color</source>
        <translation>Cor HSL</translation>
    </message>
    <message>
        <location filename="../src/widgets/trackpropertieswidget.cpp" line="60"/>
        <source>HSL Luminosity</source>
        <translation>Luminosidade HSL</translation>
    </message>
</context>
<context>
    <name>UndoButton</name>
    <message>
        <location filename="../src/qml/modules/Shotcut/Controls/UndoButton.qml" line="24"/>
        <source>Reset to default</source>
        <translation>Repor para padrão</translation>
    </message>
</context>
<context>
    <name>UnlinkedFilesDialog</name>
    <message>
        <location filename="../src/dialogs/unlinkedfilesdialog.ui" line="14"/>
        <source>Missing Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/dialogs/unlinkedfilesdialog.ui" line="26"/>
        <source>There are missing files in your project. Double-click each row to locate a file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/dialogs/unlinkedfilesdialog.cpp" line="42"/>
        <source>Missing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/dialogs/unlinkedfilesdialog.cpp" line="43"/>
        <source>Replacement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/dialogs/unlinkedfilesdialog.cpp" line="56"/>
        <source>Open File</source>
        <translation type="unfinished">Abrir Ficheiro</translation>
    </message>
</context>
<context>
    <name>Video4LinuxWidget</name>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="72"/>
        <source>Video4Linux</source>
        <translation>Video4Linux</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="135"/>
        <source>Device</source>
        <translation>Dispositivo</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="43"/>
        <source>Set the path to the video device file</source>
        <translation>Definir o atalho para o ficheiro do dispositivo de vídeo</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="46"/>
        <source>/dev/video0</source>
        <translation>/dev/video0</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="125"/>
        <source>Resolution</source>
        <translation>Resolução</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="223"/>
        <source>Width</source>
        <translation>Width</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="249"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="102"/>
        <source>Height</source>
        <translation>Altura</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="236"/>
        <source>pixels</source>
        <translation>píxeis</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="115"/>
        <source>Frame rate</source>
        <translation>Taxa de Quadros</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="82"/>
        <source>fps</source>
        <translation>fps</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="145"/>
        <source>TV Tuner</source>
        <translation>Televisão</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="157"/>
        <source>Standard</source>
        <translation>Padrão</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="167"/>
        <source>Set the television standard</source>
        <translation>Definir televisão padrão</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="171"/>
        <source>Automatic</source>
        <translation>Automático</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="176"/>
        <source>NTSC</source>
        <translation>NTSC</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="181"/>
        <source>PAL</source>
        <translation>PAL</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="186"/>
        <source>SECAM</source>
        <translation>SECAM</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="194"/>
        <source>Channel</source>
        <translation>Canal</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="213"/>
        <source>Audio Input</source>
        <translation>Entrada Áudio</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="257"/>
        <source>None</source>
        <translation>Nenhum</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="262"/>
        <source>PulseAudio</source>
        <translation>PulseAudio</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="267"/>
        <source>JACK</source>
        <translation>JACK</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="272"/>
        <source>ALSA</source>
        <translation>ALSA</translation>
    </message>
    <message>
        <location filename="../src/widgets/video4linuxwidget.ui" line="36"/>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
</context>
<context>
    <name>VideoQualityJob</name>
    <message>
        <location filename="../src/jobs/videoqualityjob.cpp" line="35"/>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <location filename="../src/jobs/videoqualityjob.cpp" line="36"/>
        <source>Open original and encoded side-by-side in the Shotcut player</source>
        <translation>Abrir, lado-a-lado, o original e o codificado no leitor do Shotcut</translation>
    </message>
    <message>
        <location filename="../src/jobs/videoqualityjob.cpp" line="40"/>
        <source>View Report</source>
        <translation>Ver Relatório</translation>
    </message>
    <message>
        <location filename="../src/jobs/videoqualityjob.cpp" line="44"/>
        <source>Show In Folder</source>
        <translation>Mostrar na Pasta</translation>
    </message>
    <message>
        <location filename="../src/jobs/videoqualityjob.cpp" line="48"/>
        <source>Measure %1</source>
        <translation>Medida %1</translation>
    </message>
    <message>
        <location filename="../src/jobs/videoqualityjob.cpp" line="87"/>
        <source>Video Quality Measurement</source>
        <translation>Avaliação da Qualidade Vídeo</translation>
    </message>
</context>
<context>
    <name>VideoWaveformScopeWidget</name>
    <message>
        <location filename="../src/widgets/scopes/videowaveformscopewidget.cpp" line="98"/>
        <source>Video Waveform</source>
        <translation>Forma de Onda Vídeo</translation>
    </message>
</context>
<context>
    <name>WebvfxProducer</name>
    <message>
        <location filename="../src/widgets/webvfxproducer.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../src/widgets/webvfxproducer.ui" line="23"/>
        <source>Make background transparent</source>
        <translation>Tornar Fundo Transparente</translation>
    </message>
    <message>
        <location filename="../src/widgets/webvfxproducer.ui" line="30"/>
        <source>Reload</source>
        <translation>Recarregar</translation>
    </message>
    <message>
        <location filename="../src/widgets/webvfxproducer.ui" line="53"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;For Advanced Users&lt;/span&gt;&lt;br/&gt;If you enable this, and you do not use the WebVfx JavaScript extension, your content will not render!&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Para Utilizadores Avançados&lt;/span&gt;&lt;br/&gt;Se activar isto, e não usar a extensão JavaScript WebVfx , o seu conteúdo não será renderizado!&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/widgets/webvfxproducer.ui" line="56"/>
        <source>Use WebVfx JavaScript extension</source>
        <translation>Usar extensão JavaScript WebVfx</translation>
    </message>
</context>
<context>
    <name>X11grabWidget</name>
    <message>
        <location filename="../src/widgets/x11grabwidget.ui" line="14"/>
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../src/widgets/x11grabwidget.ui" line="46"/>
        <source>Screen</source>
        <translation>Ecrã</translation>
    </message>
    <message>
        <location filename="../src/widgets/x11grabwidget.ui" line="30"/>
        <source>Display</source>
        <translation>Exibir</translation>
    </message>
    <message>
        <location filename="../src/widgets/x11grabwidget.ui" line="121"/>
        <source>An X11 display name of the form hostname:displaynumber.screennumber
Most users do not need to change this.</source>
        <translation>Uma exibição de nome X11 do nome da máquina:displaynumber.screennumber
A maior parte dos utilizadores não precisam alterar isto.</translation>
    </message>
    <message>
        <location filename="../src/widgets/x11grabwidget.ui" line="125"/>
        <source>:0.0</source>
        <translation>:0.0</translation>
    </message>
    <message>
        <location filename="../src/widgets/x11grabwidget.ui" line="291"/>
        <source>Position</source>
        <translation>Posição</translation>
    </message>
    <message>
        <location filename="../src/widgets/x11grabwidget.ui" line="103"/>
        <source>Center Under Mouse</source>
        <translation>Centrar Sob o Rato</translation>
    </message>
    <message>
        <location filename="../src/widgets/x11grabwidget.ui" line="108"/>
        <source>Fixed</source>
        <translation>Fixa</translation>
    </message>
    <message>
        <location filename="../src/widgets/x11grabwidget.ui" line="113"/>
        <source>Follow Mouse</source>
        <translation>Seguir o Rato</translation>
    </message>
    <message>
        <location filename="../src/widgets/x11grabwidget.ui" line="132"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../src/widgets/x11grabwidget.ui" line="66"/>
        <source>The horizontal coordinate from the left edge when using a fixed capture region.</source>
        <translation>A coordenada horizontal desde a borda esquerda ao usar a captura de região fixa.</translation>
    </message>
    <message>
        <location filename="../src/widgets/x11grabwidget.ui" line="229"/>
        <source>Y</source>
        <translation>Y</translation>
    </message>
    <message>
        <location filename="../src/widgets/x11grabwidget.ui" line="82"/>
        <source>The vertical coordinate from the top edge when using a fixed capture region.</source>
        <translation>A coordenada vertical desde a borda superior ao usar a captura de região fixa.</translation>
    </message>
    <message>
        <location filename="../src/widgets/x11grabwidget.ui" line="92"/>
        <location filename="../src/widgets/x11grabwidget.ui" line="212"/>
        <source>pixels</source>
        <translation>píxeis</translation>
    </message>
    <message>
        <location filename="../src/widgets/x11grabwidget.ui" line="20"/>
        <source>Resolution</source>
        <translation>Resolução</translation>
    </message>
    <message>
        <location filename="../src/widgets/x11grabwidget.ui" line="265"/>
        <source>Width of the capture region</source>
        <translation>Largura da região capturada</translation>
    </message>
    <message>
        <location filename="../src/widgets/x11grabwidget.ui" line="258"/>
        <source>x</source>
        <translation>x</translation>
    </message>
    <message>
        <location filename="../src/widgets/x11grabwidget.ui" line="278"/>
        <source>Height of the capture region</source>
        <translation>Altura da região capturada</translation>
    </message>
    <message>
        <location filename="../src/widgets/x11grabwidget.ui" line="142"/>
        <source>Show the capture region</source>
        <translation>Mostrar a região capturada</translation>
    </message>
    <message>
        <location filename="../src/widgets/x11grabwidget.ui" line="219"/>
        <source>Draw the mouse cursor</source>
        <translation>Desenhar o cursor do rato</translation>
    </message>
    <message>
        <location filename="../src/widgets/x11grabwidget.ui" line="149"/>
        <source>Audio Input</source>
        <translation>Entrada Áudio</translation>
    </message>
    <message>
        <location filename="../src/widgets/x11grabwidget.ui" line="185"/>
        <source>Choose an audio input method to use during capture.</source>
        <translation>Escolha um método de entrada áudio para usar durante a captura.</translation>
    </message>
    <message>
        <location filename="../src/widgets/x11grabwidget.ui" line="189"/>
        <source>None</source>
        <translation>Nenhum</translation>
    </message>
    <message>
        <location filename="../src/widgets/x11grabwidget.ui" line="194"/>
        <source>PulseAudio</source>
        <translation>PulseAudio</translation>
    </message>
    <message>
        <location filename="../src/widgets/x11grabwidget.ui" line="199"/>
        <source>JACK</source>
        <translation>JACK</translation>
    </message>
    <message>
        <location filename="../src/widgets/x11grabwidget.ui" line="204"/>
        <source>ALSA</source>
        <translation>ALSA</translation>
    </message>
    <message>
        <location filename="../src/widgets/x11grabwidget.ui" line="56"/>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <location filename="../src/widgets/x11grabwidget.ui" line="159"/>
        <source>Use this when you are going to capture Shotcut itself.
It makes the capture run in the background, but
you will not be able to simultaneously send
the screen capture to SDI/HDMI in this mode.</source>
        <translation>Use isto quando for capturar o próprio Shotcut.
Faz com a captura seja executada em fundo, mas
não poderá enviar simultaneamente a captura de
ecrã para SDI/HDMI, se usar este modo.</translation>
    </message>
    <message>
        <location filename="../src/widgets/x11grabwidget.ui" line="165"/>
        <source>Capture Shotcut</source>
        <translation>Captura Shotcut</translation>
    </message>
</context>
<context>
    <name>audioloudnessscope</name>
    <message>
        <location filename="../src/qml/scopes/audioloudness/audioloudnessscope.qml" line="118"/>
        <source>Momentary Loudness.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/scopes/audioloudness/audioloudnessscope.qml" line="152"/>
        <source>Short-term Loudness.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/scopes/audioloudness/audioloudnessscope.qml" line="186"/>
        <source>Integrated Loudness.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/scopes/audioloudness/audioloudnessscope.qml" line="220"/>
        <source>Loudness Range.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/scopes/audioloudness/audioloudnessscope.qml" line="254"/>
        <source>Peak.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/scopes/audioloudness/audioloudnessscope.qml" line="288"/>
        <source>True Peak.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>filterview</name>
    <message>
        <location filename="../src/qml/views/filter/filterview.qml" line="121"/>
        <source>Nothing selected</source>
        <translation>Nada seleccionado</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/filterview.qml" line="133"/>
        <source>Add a filter</source>
        <translation>Adicionar um filtro</translation>
    </message>
    <message>
        <location filename="../src/qml/views/filter/filterview.qml" line="145"/>
        <source>Remove selected filter</source>
        <translation>Remover filtro seleccionado</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../src/main.cpp" line="190"/>
        <source>Fill the screen with the Shotcut window.</source>
        <translation>Encher o ecrã com a janela do Shotcut</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="194"/>
        <source>Use GPU processing.</source>
        <translation>Usar processamento GPU</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="197"/>
        <source>A file to open.</source>
        <translation>Um ficheiro para abrir.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="234"/>
        <source>Loading plugins...</source>
        <translation>A carregar plugins...</translation>
    </message>
</context>
<context>
    <name>meta</name>
    <message>
        <location filename="../src/qml/filters/webvfx_circular_frame/meta.qml" line="7"/>
        <source>Circular Frame (HTML)</source>
        <translation>Quadro Circular (HTML)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/meta.qml" line="7"/>
        <source>Copy Channel</source>
        <translation>Copiar Canal</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_balance/meta.qml" line="7"/>
        <source>Balance</source>
        <translation>Balanço</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_pan/meta.qml" line="7"/>
        <source>Pan</source>
        <translation>Pan</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_mono/meta.qml" line="7"/>
        <source>Downmix</source>
        <translation>Downmix</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_swapchannels/meta.qml" line="7"/>
        <source>Swap Channels</source>
        <translation>Alternar Canais</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/rotate/meta.qml" line="7"/>
        <source>Rotate</source>
        <translation>Rodar</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/meta.qml" line="6"/>
        <source>Stabilize</source>
        <translation>Estabilizar</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/invert/meta.qml" line="6"/>
        <source>Invert Colors</source>
        <translation>Inverter Cores</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sepia/meta.qml" line="6"/>
        <source>Sepia Tone</source>
        <translation>Tonalidade Sépia</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/movit_diffusion/meta.qml" line="6"/>
        <source>Diffusion</source>
        <translation>Difusão</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop/meta.qml" line="6"/>
        <source>Crop</source>
        <translation>Recortar</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta.qml" line="6"/>
        <source>Color Grading</source>
        <translation>Gradiente de Cor</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/wave/meta.qml" line="6"/>
        <source>Wave</source>
        <translation>Onda</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mirror/meta.qml" line="6"/>
        <source>Mirror</source>
        <translation>Espelho</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/webvfx/meta.qml" line="6"/>
        <source>Overlay HTML</source>
        <translation>Sobreposição HTML</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_fadein/meta.qml" line="8"/>
        <source>Fade In Audio</source>
        <translation>Aumento gradual do Áudio</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_fadeout/meta.qml" line="8"/>
        <source>Fade Out Audio</source>
        <translation>Desvanecimento do Áudio</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fadein_brightness/meta.qml" line="7"/>
        <location filename="../src/qml/filters/fadein_movit/meta.qml" line="7"/>
        <source>Fade In Video</source>
        <translation>Aumento gradual do Vídeo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fadeout_brightness/meta.qml" line="7"/>
        <location filename="../src/qml/filters/fadeout_movit/meta.qml" line="7"/>
        <source>Fade Out Video</source>
        <translation>Desvanecimento do Vídeo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/opacity/meta.qml" line="7"/>
        <source>Opacity</source>
        <translation>Opacidade</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/meta.qml" line="7"/>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/webvfx_threejs_text/meta.qml" line="7"/>
        <source>3D Text (HTML)</source>
        <translation>Texto 3D (HTML)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/meta.qml" line="7"/>
        <source>Band Pass</source>
        <translation>Band Pass</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_highpass/meta.qml" line="7"/>
        <source>High Pass</source>
        <translation>High Pass</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_lowpass/meta.qml" line="7"/>
        <source>Low Pass</source>
        <translation>Low Pass</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dust/meta.qml" line="6"/>
        <source>Old Film: Dust</source>
        <translation>Filme Antigo: Pó</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grain/meta.qml" line="6"/>
        <source>Old Film: Grain</source>
        <translation>Filme Antigo: Grão</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lines/meta.qml" line="6"/>
        <source>Old Film: Scratches</source>
        <translation>Filme Antigo: Riscos</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/meta.qml" line="6"/>
        <source>Old Film: Projector</source>
        <translation>Filme Antigo: Projector</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tcolor/meta.qml" line="6"/>
        <source>Old Film: %1</source>
        <translation>Filme Antigo: %1</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_basstreble/meta.qml" line="7"/>
        <source>Bass &amp; Treble</source>
        <translation>Graves &amp; Agudos</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/meta.qml" line="7"/>
        <source>Compressor</source>
        <translation>Compressor</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_delay/meta.qml" line="7"/>
        <source>Delay</source>
        <translation>Atraso</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_expander/meta.qml" line="7"/>
        <source>Expander</source>
        <translation>Expansor</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_limiter/meta.qml" line="7"/>
        <source>Limiter</source>
        <translation>Limitador</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_notch/meta.qml" line="7"/>
        <source>Notch</source>
        <translation>Entalhe</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/meta.qml" line="7"/>
        <source>Reverb</source>
        <translation>Reverbação</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_gain/meta.qml" line="7"/>
        <source>Gain / Volume</source>
        <translation>Grão/Volume</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_mute/meta.qml" line="8"/>
        <source>Mute</source>
        <translation>Sem som</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/meta.qml" line="24"/>
        <source>Alpha Channel: Adjust</source>
        <translation>Canal Alfa: Ajustar</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/meta.qml" line="24"/>
        <source>Alpha Channel: View</source>
        <translation>Canal Alfa: Visualizar</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bluescreen0r/meta.qml" line="24"/>
        <source>Chroma Key: Simple</source>
        <translation>Chroma Key: Simples</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/meta.qml" line="24"/>
        <source>Key Spill: Advanced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/meta.qml" line="24"/>
        <source>Chroma Key: Advanced</source>
        <translation>Chroma Key: Avançado</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spillsuppress/meta.qml" line="24"/>
        <source>Key Spill: Simple</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/meta.qml" line="7"/>
        <source>Normalize: One Pass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/meta.qml" line="7"/>
        <source>Normalize: Two Pass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/brightness/meta.qml" line="6"/>
        <source>Brightness</source>
        <translation type="unfinished">Brilho</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/contrast/meta.qml" line="6"/>
        <source>Contrast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/smartblur/meta.qml" line="24"/>
        <source>Reduce Noise</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>meta_affine</name>
    <message>
        <location filename="../src/qml/filters/size_position/meta_affine.qml" line="7"/>
        <source>Size and Position</source>
        <translation>Tamanho e Posição</translation>
    </message>
</context>
<context>
    <name>meta_boxblur</name>
    <message>
        <location filename="../src/qml/filters/blur/meta_boxblur.qml" line="6"/>
        <source>Blur</source>
        <translation>Desfocar</translation>
    </message>
</context>
<context>
    <name>meta_frei0r</name>
    <message>
        <location filename="../src/qml/filters/saturation/meta_frei0r.qml" line="6"/>
        <source>Saturation</source>
        <translation>Saturação</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/meta_frei0r.qml" line="6"/>
        <source>Glow</source>
        <translation>Brilho</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_frei0r.qml" line="6"/>
        <source>Sharpen</source>
        <translation>Nitidez</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/white/meta_frei0r.qml" line="6"/>
        <source>White Balance</source>
        <translation>Balanço de Brancos</translation>
    </message>
</context>
<context>
    <name>meta_frei0r_coloradj</name>
    <message>
        <location filename="../src/qml/filters/color/meta_frei0r_coloradj.qml" line="7"/>
        <source>Color Grading</source>
        <translation>Gradiente de Cor</translation>
    </message>
</context>
<context>
    <name>meta_movit</name>
    <message>
        <location filename="../src/qml/filters/saturation/meta_movit.qml" line="6"/>
        <source>Saturation</source>
        <translation>Saturação</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/meta_movit.qml" line="6"/>
        <source>Vignette</source>
        <translation>Vinheta</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/meta_movit.qml" line="6"/>
        <source>Color Grading</source>
        <translation>Gradiente de Cor</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop/meta_movit.qml" line="6"/>
        <source>Crop</source>
        <translation>Recortar</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/meta_movit.qml" line="6"/>
        <source>Glow</source>
        <translation>Brilho</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/meta_movit.qml" line="6"/>
        <source>Blur</source>
        <translation>Desfocar</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/meta_movit.qml" line="6"/>
        <source>Sharpen</source>
        <translation>Nitidez</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/white/meta_movit.qml" line="6"/>
        <source>White Balance</source>
        <translation>Balanço de Brancos</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/mirror/meta_movit.qml" line="6"/>
        <source>Mirror</source>
        <translation>Espelho</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/opacity/meta_movit.qml" line="7"/>
        <source>Opacity</source>
        <translation>Opacidade</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/size_position/meta_movit.qml" line="7"/>
        <source>Size and Position</source>
        <translation>Tamanho e Posição</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/brightness/meta_movit.qml" line="6"/>
        <source>Brightness</source>
        <translation type="unfinished">Brilho</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/contrast/meta_movit.qml" line="6"/>
        <source>Contrast</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>meta_oldfilm</name>
    <message>
        <location filename="../src/qml/filters/vignette/meta_oldfilm.qml" line="6"/>
        <source>Vignette</source>
        <translation>Vinheta</translation>
    </message>
</context>
<context>
    <name>text_outline</name>
    <message>
        <location filename="../src/qml/htmleditor/text_outline.qml" line="22"/>
        <source>Width</source>
        <translation>Largura</translation>
    </message>
    <message>
        <location filename="../src/qml/htmleditor/text_outline.qml" line="34"/>
        <source>pixels</source>
        <translation>píxeis</translation>
    </message>
    <message>
        <location filename="../src/qml/htmleditor/text_outline.qml" line="37"/>
        <source>Color</source>
        <translation>Cor</translation>
    </message>
    <message>
        <location filename="../src/qml/htmleditor/text_outline.qml" line="73"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../src/qml/htmleditor/text_outline.qml" line="85"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/qml/htmleditor/text_outline.qml" line="92"/>
        <source>Please choose a color</source>
        <translation>Por favor escolha uma cor</translation>
    </message>
</context>
<context>
    <name>text_shadow</name>
    <message>
        <location filename="../src/qml/htmleditor/text_shadow.qml" line="22"/>
        <source>Horizontal</source>
        <translation>Horizontal</translation>
    </message>
    <message>
        <location filename="../src/qml/htmleditor/text_shadow.qml" line="34"/>
        <location filename="../src/qml/htmleditor/text_shadow.qml" line="49"/>
        <location filename="../src/qml/htmleditor/text_shadow.qml" line="64"/>
        <source>pixels</source>
        <translation>píxeis</translation>
    </message>
    <message>
        <location filename="../src/qml/htmleditor/text_shadow.qml" line="37"/>
        <source>Vertical</source>
        <translation>Vertical</translation>
    </message>
    <message>
        <location filename="../src/qml/htmleditor/text_shadow.qml" line="52"/>
        <source>Softness</source>
        <translation>Suavidade</translation>
    </message>
    <message>
        <location filename="../src/qml/htmleditor/text_shadow.qml" line="67"/>
        <source>Color</source>
        <translation>Cor</translation>
    </message>
    <message>
        <location filename="../src/qml/htmleditor/text_shadow.qml" line="103"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../src/qml/htmleditor/text_shadow.qml" line="119"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/qml/htmleditor/text_shadow.qml" line="126"/>
        <source>Please choose a color</source>
        <translation>Por favor escolha uma cor</translation>
    </message>
</context>
<context>
    <name>timeline</name>
    <message>
        <location filename="../src/qml/timeline/timeline.qml" line="307"/>
        <source>Insert</source>
        <translation>Inserir</translation>
    </message>
    <message>
        <location filename="../src/qml/timeline/timeline.qml" line="307"/>
        <source>Overwrite</source>
        <translation>Sobrescrever</translation>
    </message>
    <message>
        <location filename="../src/qml/timeline/timeline.qml" line="371"/>
        <source>Add Audio Track</source>
        <translation>Adicionar Faixa Áudio</translation>
    </message>
    <message>
        <location filename="../src/qml/timeline/timeline.qml" line="376"/>
        <source>Add Video Track</source>
        <translation>Adicionar Faixa Vídeo</translation>
    </message>
    <message>
        <location filename="../src/qml/timeline/timeline.qml" line="381"/>
        <source>Insert Track</source>
        <translation>Inserir Faixa</translation>
    </message>
    <message>
        <location filename="../src/qml/timeline/timeline.qml" line="385"/>
        <source>Remove Track</source>
        <translation>Remover Faixa</translation>
    </message>
    <message>
        <location filename="../src/qml/timeline/timeline.qml" line="398"/>
        <source>Make Tracks Shorter</source>
        <translation>Reduzir Faixas</translation>
    </message>
    <message>
        <location filename="../src/qml/timeline/timeline.qml" line="403"/>
        <source>Make Tracks Taller</source>
        <translation>Aumentar Faixas</translation>
    </message>
    <message>
        <location filename="../src/qml/timeline/timeline.qml" line="390"/>
        <source>Ripple All Tracks</source>
        <translation>Intercalar Todas as Faixas</translation>
    </message>
    <message>
        <location filename="../src/qml/timeline/timeline.qml" line="408"/>
        <source>Show Audio Waveforms</source>
        <translation>Mostrar Formas de Onda Áudio</translation>
    </message>
    <message>
        <location filename="../src/qml/timeline/timeline.qml" line="420"/>
        <source>Show Video Thumbnails</source>
        <translation>Mostrar Miniaturas dos Vídeos</translation>
    </message>
    <message>
        <location filename="../src/qml/timeline/timeline.qml" line="426"/>
        <source>Reload</source>
        <translation>Recarregar</translation>
    </message>
</context>
<context>
    <name>ui</name>
    <message>
        <location filename="../src/qml/filters/movit_diffusion/ui.qml" line="34"/>
        <location filename="../src/qml/filters/webvfx_circular_frame/ui.qml" line="46"/>
        <source>Radius</source>
        <translation>Raio</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/movit_diffusion/ui.qml" line="52"/>
        <source>Blurriness</source>
        <translation>Desfocagem</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_gain/ui.qml" line="49"/>
        <source>Gain</source>
        <translation>Ganho</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/webvfx_circular_frame/ui.qml" line="62"/>
        <location filename="../src/qml/filters/webvfx_threejs_text/ui.qml" line="127"/>
        <source>Color</source>
        <translation>Cor</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_balance/ui.qml" line="40"/>
        <location filename="../src/qml/filters/audio_pan/ui.qml" line="48"/>
        <location filename="../src/qml/filters/audio_pan/ui.qml" line="53"/>
        <location filename="../src/qml/filters/crop/ui.qml" line="175"/>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="329"/>
        <source>Left</source>
        <translation>Esquerda</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_balance/ui.qml" line="47"/>
        <location filename="../src/qml/filters/audio_pan/ui.qml" line="48"/>
        <location filename="../src/qml/filters/audio_pan/ui.qml" line="60"/>
        <location filename="../src/qml/filters/crop/ui.qml" line="192"/>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="341"/>
        <source>Right</source>
        <translation>Direita</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="43"/>
        <source>Copy from</source>
        <translation>Copiar de</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="46"/>
        <source>Left to right</source>
        <translation>Esquerda para a Direita</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_channelcopy/ui.qml" line="46"/>
        <source>Right to left</source>
        <translation>Direita para a Esquerda</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_pan/ui.qml" line="42"/>
        <source>Channel</source>
        <translation>Canal</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/rotate/ui.qml" line="62"/>
        <source>Rotation</source>
        <translation>Rotação</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/rotate/ui.qml" line="69"/>
        <source> degree</source>
        <translation>grau</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/rotate/ui.qml" line="77"/>
        <location filename="../src/qml/filters/webvfx_ruttetraizer/ui.qml" line="141"/>
        <source>Scale</source>
        <translation>Graduação</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/rotate/ui.qml" line="96"/>
        <source>X offset</source>
        <translation>Desvio X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/rotate/ui.qml" line="108"/>
        <source>Y offset</source>
        <translation>Desvio Y</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="31"/>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="33"/>
        <source>Analyzing...</source>
        <translation>A analisar...</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="34"/>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="37"/>
        <source>Analysis complete.</source>
        <translation>Análise concluída.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="38"/>
        <source>Click &quot;Analyze&quot; to use this filter.</source>
        <translation>Clique em &quot;Analisar&quot; para usar este filtro.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="97"/>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="55"/>
        <source>Target Loudness</source>
        <translation>Intensidade de som Alvo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="99"/>
        <source>The target loudness of the output in LUFS.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="116"/>
        <source>Analysis Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="118"/>
        <source>The amount of history to use to calculate the input loudness.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="135"/>
        <source>Maximum Gain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="137"/>
        <source>The maximum that the gain can be increased.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="154"/>
        <source>Minimum Gain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="156"/>
        <source>The maximum that the gain can be decreased.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="173"/>
        <source>Maximum Rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="175"/>
        <source>The maximum rate that the gain can be changed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="250"/>
        <source>Input Loudness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="252"/>
        <source>Status indicator showing the loudness measured on the input.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="268"/>
        <source>Output Gain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="270"/>
        <source>Status indicator showing the gain being applied.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="285"/>
        <source>Reset</source>
        <translation type="unfinished">Repor</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="287"/>
        <source>Status indicator showing when the loudness measurement is reset.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="41"/>
        <source>Click Analyze to use this filter.</source>
        <translation>Clique em Analisar para usar este filtro.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="66"/>
        <source>Select a file to store analysis results.</source>
        <translation>Seleccione um ficheiro para guardar os resultados da análise.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="106"/>
        <source>&lt;b&gt;Analyze Options&lt;/b&gt;</source>
        <translation>&lt;b&gt;Opções de Análise&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="111"/>
        <source>Shakiness</source>
        <translation>Tremor</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="128"/>
        <source>Accuracy</source>
        <translation>Precisão</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_normalize_2p/ui.qml" line="74"/>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="171"/>
        <source>Analyze</source>
        <translation>Analisar</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="145"/>
        <source>&lt;b&gt;Filter Options&lt;/b&gt;</source>
        <translation>&lt;b&gt;Opções de Filtros&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/stabilize/ui.qml" line="150"/>
        <source>Zoom</source>
        <translation>Ampliação</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sepia/ui.qml" line="52"/>
        <source>Yellow-Blue</source>
        <translation>Amarelo-Azul</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sepia/ui.qml" line="67"/>
        <source>Cyan-Red</source>
        <translation>Ciano-Vermelho</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_fadein/ui.qml" line="45"/>
        <location filename="../src/qml/filters/audio_fadeout/ui.qml" line="45"/>
        <location filename="../src/qml/filters/fadein_brightness/ui.qml" line="46"/>
        <location filename="../src/qml/filters/fadein_movit/ui.qml" line="46"/>
        <location filename="../src/qml/filters/fadeout_brightness/ui.qml" line="48"/>
        <location filename="../src/qml/filters/fadeout_movit/ui.qml" line="48"/>
        <source>Duration</source>
        <translation>Duração</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop/ui.qml" line="102"/>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="335"/>
        <source>Center</source>
        <translation>Centro</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop/ui.qml" line="124"/>
        <source>Center bias</source>
        <translation>Tendência central</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop/ui.qml" line="141"/>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="353"/>
        <source>Top</source>
        <translation>Superior</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/crop/ui.qml" line="158"/>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="365"/>
        <source>Bottom</source>
        <translation>Inferior</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/ui.qml" line="52"/>
        <location filename="../src/qml/filters/audio_basstreble/ui.qml" line="170"/>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="71"/>
        <location filename="../src/qml/filters/audio_delay/ui.qml" line="50"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="58"/>
        <location filename="../src/qml/filters/audio_highpass/ui.qml" line="50"/>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="63"/>
        <location filename="../src/qml/filters/audio_lowpass/ui.qml" line="52"/>
        <location filename="../src/qml/filters/audio_normalize_1p/ui.qml" line="86"/>
        <location filename="../src/qml/filters/audio_notch/ui.qml" line="52"/>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="104"/>
        <location filename="../src/qml/filters/bluescreen0r/ui.qml" line="51"/>
        <location filename="../src/qml/filters/color/ui.qml" line="70"/>
        <location filename="../src/qml/filters/contrast/ui.qml" line="54"/>
        <location filename="../src/qml/filters/crop/ui.qml" line="83"/>
        <location filename="../src/qml/filters/dust/ui.qml" line="48"/>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="133"/>
        <location filename="../src/qml/filters/grain/ui.qml" line="49"/>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="99"/>
        <location filename="../src/qml/filters/lines/ui.qml" line="52"/>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="60"/>
        <location filename="../src/qml/filters/rotate/ui.qml" line="52"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="110"/>
        <location filename="../src/qml/filters/sepia/ui.qml" line="38"/>
        <location filename="../src/qml/filters/smartblur/ui.qml" line="58"/>
        <location filename="../src/qml/filters/tcolor/ui.qml" line="48"/>
        <location filename="../src/qml/filters/wave/ui.qml" line="44"/>
        <location filename="../src/qml/filters/webvfx_ruttetraizer/ui.qml" line="62"/>
        <location filename="../src/qml/filters/webvfx_threejs_text/ui.qml" line="70"/>
        <location filename="../src/qml/filters/white/ui.qml" line="66"/>
        <source>Preset</source>
        <translation>Predefinição</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/ui.qml" line="63"/>
        <location filename="../src/qml/filters/audio_notch/ui.qml" line="63"/>
        <source>Center frequency</source>
        <translation>Frequência central</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/ui.qml" line="81"/>
        <location filename="../src/qml/filters/audio_notch/ui.qml" line="81"/>
        <source>Bandwidth</source>
        <translation>Largura de Banda</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/ui.qml" line="99"/>
        <location filename="../src/qml/filters/audio_highpass/ui.qml" line="78"/>
        <location filename="../src/qml/filters/audio_lowpass/ui.qml" line="83"/>
        <location filename="../src/qml/filters/audio_notch/ui.qml" line="99"/>
        <source>Rolloff rate</source>
        <translation>Taxa de Rolagem</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/ui.qml" line="116"/>
        <location filename="../src/qml/filters/audio_delay/ui.qml" line="102"/>
        <location filename="../src/qml/filters/audio_highpass/ui.qml" line="95"/>
        <location filename="../src/qml/filters/audio_lowpass/ui.qml" line="101"/>
        <location filename="../src/qml/filters/audio_notch/ui.qml" line="116"/>
        <source>Dry</source>
        <translation>Seco</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_bandpass/ui.qml" line="125"/>
        <location filename="../src/qml/filters/audio_delay/ui.qml" line="111"/>
        <location filename="../src/qml/filters/audio_highpass/ui.qml" line="104"/>
        <location filename="../src/qml/filters/audio_lowpass/ui.qml" line="110"/>
        <location filename="../src/qml/filters/audio_notch/ui.qml" line="125"/>
        <source>Wet</source>
        <translation>Húmido</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/ui.qml" line="82"/>
        <source>Shadows (Lift)</source>
        <translation>Sombras (Elevação)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/ui.qml" line="87"/>
        <source>Midtones (Gamma)</source>
        <translation>Meios Tons (Gama)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/ui.qml" line="92"/>
        <source>Highlights (Gain)</source>
        <translation>Realces (Ganho)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/wave/ui.qml" line="60"/>
        <source>Amplitude</source>
        <translation>Amplitude</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/wave/ui.qml" line="75"/>
        <source>Speed</source>
        <translation>Velocidade</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/wave/ui.qml" line="92"/>
        <source>Deform horizontally?</source>
        <translation>Deformar horizontalmente?</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/wave/ui.qml" line="106"/>
        <source>Deform vertically?</source>
        <translation>Deformar verticalmente?</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/webvfx/ui.qml" line="80"/>
        <source>No File Loaded</source>
        <translation>Nenhum Ficheiro Carregado</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/webvfx/ui.qml" line="82"/>
        <source>No HTML file loaded. Click &quot;Open&quot; or &quot;New&quot; to load a file.</source>
        <translation>Nenhum ficheiro HTML carregado. Clique em &quot;Abrir&quot; ou &quot;Novo&quot; para carregar um ficheiro.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/webvfx/ui.qml" line="143"/>
        <source>&lt;b&gt;File:&lt;/b&gt;</source>
        <translation>&lt;b&gt;Ficheiro:&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/webvfx/ui.qml" line="155"/>
        <source>Use WebVfx JavaScript extension</source>
        <translation>Usar extensão JavaScript WebVfx</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/webvfx/ui.qml" line="158"/>
        <source>For Advanced Users: </source>
        <translation>Para Utilizadores Avançados:</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/webvfx/ui.qml" line="159"/>
        <source>If you enable this, and you do not use the WebVfx JavaScript extension, your content will not render!</source>
        <translation>Se activar isto e não usar a extensão JavaScript WebVfx, o seu conteúdo não será renderizado!</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/webvfx/ui.qml" line="171"/>
        <source>Confirm Selection</source>
        <translation>Confirmar Selecção</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/webvfx/ui.qml" line="172"/>
        <source>Do you still want to use this?</source>
        <translation>Ainda deseja usar isto?</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/webvfx/ui.qml" line="183"/>
        <source>Open...</source>
        <translation>Abrir...</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/webvfx/ui.qml" line="186"/>
        <source>Open HTML File</source>
        <translation>Abrir Ficheiro HTML</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/webvfx/ui.qml" line="190"/>
        <source>Load an existing HTML file.</source>
        <translation>Carrega um ficheiro HTML existente.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/webvfx/ui.qml" line="195"/>
        <source>New...</source>
        <translation>Novo...</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/webvfx/ui.qml" line="198"/>
        <source>Save HTML File</source>
        <translation>Guardar Ficheiro HTML</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/webvfx/ui.qml" line="202"/>
        <source>Load new HTML file.</source>
        <translation>Carrega um novo ficheiro HTML.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/webvfx/ui.qml" line="214"/>
        <source>Edit...</source>
        <translation>Editar...</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/webvfx/ui.qml" line="234"/>
        <source>Reload</source>
        <translation>Recarregar</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/white/ui.qml" line="80"/>
        <source>Neutral color</source>
        <translation>Cor Neutra</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/white/ui.qml" line="103"/>
        <source>Color temperature</source>
        <translation>Temperatura da Cor</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="46"/>
        <source>Bottom Left</source>
        <translation>Inferior Esquerda</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="51"/>
        <source>Bottom Right</source>
        <translation>Inferior Direita</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="56"/>
        <source>Top Left</source>
        <translation>Superior Esquerda</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="61"/>
        <source>Top Right</source>
        <translation>Superior Direita</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="66"/>
        <source>Lower Third</source>
        <translation>Terço Inferior</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="145"/>
        <location filename="../src/qml/filters/webvfx_threejs_text/ui.qml" line="82"/>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="170"/>
        <source>Insert field</source>
        <translation>Inserir campo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="176"/>
        <source>Timecode</source>
        <translation>Código de Tempo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="180"/>
        <source>Frame #</source>
        <comment>Frame number</comment>
        <translation>Quadro #</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="184"/>
        <source>File date</source>
        <translation>Data do ficheiro</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="188"/>
        <source>File name</source>
        <translation>Nome do ficheiro</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="194"/>
        <location filename="../src/qml/filters/webvfx_threejs_text/ui.qml" line="95"/>
        <source>Font</source>
        <translation>Fonte</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="221"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="248"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="221"/>
        <location filename="../src/qml/filters/webvfx_threejs_text/ui.qml" line="115"/>
        <source>Bold</source>
        <translation>Negrito</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="221"/>
        <source>Light</source>
        <comment>thin font stroke</comment>
        <translation>Leve</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="235"/>
        <source>Outline</source>
        <translation>Contorno</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="245"/>
        <location filename="../src/qml/filters/webvfx_ruttetraizer/ui.qml" line="91"/>
        <source>Thickness</source>
        <translation>Espessura</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="259"/>
        <source>Background</source>
        <translation>Fundo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="269"/>
        <source>Padding</source>
        <translation>Enchimento</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="283"/>
        <source>Position</source>
        <translation>Posição</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dust/ui.qml" line="59"/>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="303"/>
        <location filename="../src/qml/filters/webvfx_threejs_text/ui.qml" line="148"/>
        <source>Size</source>
        <translation>Tamanho</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="55"/>
        <source>Mode</source>
        <translation>Modo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="63"/>
        <source>No Change</source>
        <translation>Sem Alteração</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="64"/>
        <source>Shave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="65"/>
        <source>Shrink Hard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="66"/>
        <source>Shrink Soft</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="67"/>
        <source>Grow Hard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="68"/>
        <source>Grow Soft</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="70"/>
        <source>Blur</source>
        <translation type="unfinished">Desfocar</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="81"/>
        <location filename="../src/qml/filters/dust/ui.qml" line="75"/>
        <location filename="../src/qml/filters/lines/ui.qml" line="78"/>
        <source>Amount</source>
        <translation>Quantidade</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="104"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="304"/>
        <source>Invert</source>
        <translation>Inverter</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="324"/>
        <source>Horizontal fit</source>
        <translation>Ajuste horizontal</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="348"/>
        <source>Vertical fit</source>
        <translation>Ajuste vertical</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_basstreble/ui.qml" line="202"/>
        <source>Bass</source>
        <translation>Graves</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_basstreble/ui.qml" line="223"/>
        <location filename="../src/qml/filters/dynamictext/ui.qml" line="359"/>
        <source>Middle</source>
        <translation>Médios</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_basstreble/ui.qml" line="244"/>
        <source>Treble</source>
        <translation>Agudos</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/fadein_brightness/ui.qml" line="70"/>
        <location filename="../src/qml/filters/fadein_movit/ui.qml" line="63"/>
        <location filename="../src/qml/filters/fadeout_brightness/ui.qml" line="72"/>
        <location filename="../src/qml/filters/fadeout_movit/ui.qml" line="65"/>
        <source>Adjust opacity instead of fade with black</source>
        <translation>Ajustar opacidade em vez de misturar branco</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/opacity/ui.qml" line="44"/>
        <source>Opacity</source>
        <translation>Opacidade</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/webvfx_threejs_text/ui.qml" line="33"/>
        <source>3D Text</source>
        <translation>Texto 3D</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/webvfx_threejs_text/ui.qml" line="122"/>
        <source>Beveled</source>
        <translation>Biselado</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/webvfx_ruttetraizer/ui.qml" line="107"/>
        <source>Density</source>
        <translation>Densidade</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/webvfx_ruttetraizer/ui.qml" line="124"/>
        <location filename="../src/qml/filters/webvfx_threejs_text/ui.qml" line="164"/>
        <source>Depth</source>
        <translation>Profundidade</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/webvfx_ruttetraizer/ui.qml" line="157"/>
        <source>X Axis Rotation</source>
        <translation>Rotação Eixo X</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/webvfx_ruttetraizer/ui.qml" line="174"/>
        <source>Y Axis Rotation</source>
        <translation>Rotação Eixo Y</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/webvfx_threejs_text/ui.qml" line="181"/>
        <source>Tilt</source>
        <translation>Inclinação</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/webvfx_threejs_text/ui.qml" line="198"/>
        <source>Horizontal</source>
        <translation>Horizontal</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/webvfx_threejs_text/ui.qml" line="215"/>
        <source>Vertical</source>
        <translation>Vertical</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_highpass/ui.qml" line="60"/>
        <location filename="../src/qml/filters/audio_lowpass/ui.qml" line="63"/>
        <source>Cutoff frequency</source>
        <translation>Frequência de corte</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/grain/ui.qml" line="60"/>
        <source>Noise</source>
        <translation>Ruído</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/brightness/ui.qml" line="41"/>
        <location filename="../src/qml/filters/grain/ui.qml" line="76"/>
        <location filename="../src/qml/filters/webvfx_ruttetraizer/ui.qml" line="74"/>
        <source>Brightness</source>
        <translation>Brilho</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lines/ui.qml" line="63"/>
        <source>Width</source>
        <translation>Largura</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lines/ui.qml" line="93"/>
        <source>Darkness</source>
        <translation>Obscuridade</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/lines/ui.qml" line="108"/>
        <source>Lightness</source>
        <translation>Claridade</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="71"/>
        <source>Vertical amount</source>
        <translation>Quantidade vertical</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="86"/>
        <source>Vertical frequency</source>
        <translation>Frequência vertical</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="102"/>
        <source>Brightness up</source>
        <translation>Mais brilho</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="117"/>
        <source>Brightness down</source>
        <translation>Menos brilho</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="132"/>
        <source>Brightness frequency</source>
        <translation>Frequência do brilho</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="148"/>
        <source>Uneven develop up</source>
        <translation>Desenvolvimento desigual para cima</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="163"/>
        <source>Uneven develop down</source>
        <translation>Desenvolvimento desigual para baixo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/oldfilm/ui.qml" line="178"/>
        <source>Uneven develop duration</source>
        <translation>Duração do desenvolvimento desigual</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spillsuppress/ui.qml" line="46"/>
        <location filename="../src/qml/filters/tcolor/ui.qml" line="59"/>
        <source>Green</source>
        <translation>Verde</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tcolor/ui.qml" line="67"/>
        <source> Red</source>
        <translation>Vermelho</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/tcolor/ui.qml" line="75"/>
        <source>Yellow</source>
        <translation>Amarelo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/spillsuppress/ui.qml" line="52"/>
        <location filename="../src/qml/filters/tcolor/ui.qml" line="83"/>
        <source>Blue</source>
        <translation>Azul</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="82"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="69"/>
        <source>RMS</source>
        <translation>RMS</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="84"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="71"/>
        <source>The balance between the RMS and peak envelope followers. RMS is generally better for subtle, musical compression and peak is better for heavier, fast compression and percussion.</source>
        <translation>Balanço entre os adeptos do RMS e picos. O RMS é normalmente melhor para compressão musical fina e o pico é melhor para compressões rápidas, mais pesadas e percursão.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="92"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="79"/>
        <source>Peak</source>
        <translation>Pico</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="104"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="91"/>
        <source>Attack</source>
        <translation>Ataque</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="123"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="110"/>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="116"/>
        <source>Release</source>
        <translation>Soltar</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_adjust/ui.qml" line="69"/>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="142"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="129"/>
        <location filename="../src/qml/filters/smartblur/ui.qml" line="108"/>
        <source>Threshold</source>
        <translation>Limite</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="144"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="131"/>
        <source>The point at which the compressor will start to kick in.</source>
        <translation>Ponto a partir do qual o compressor começa a actuar.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="163"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="150"/>
        <source>Ratio</source>
        <translation>Rácio</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="165"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="152"/>
        <source>The gain reduction ratio used when the signal level exceeds the threshold.</source>
        <translation>Índice de redução de ganho usado quando o nível do sinal excede o limiar.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="183"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="170"/>
        <source>Knee radius</source>
        <translation>Knee radius</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="185"/>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="172"/>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="220"/>
        <source>The distance from the threshold where the knee curve starts.</source>
        <translation>Distância entre o limite e o joelho onde se inicia a curva.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="204"/>
        <source>Makeup gain</source>
        <translation>Ganho de correcção</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="206"/>
        <source>The gain of the makeup input signal.</source>
        <translation>Ganho do sinal de entrada corrigido.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="282"/>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="194"/>
        <source>Gain Reduction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="284"/>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="196"/>
        <source>Status indicator showing the gain reduction applied by the compressor.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_compressor/ui.qml" line="300"/>
        <source>About dynamic range compression</source>
        <translation>Acerca da compressão do intervalo dinâmico</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_delay/ui.qml" line="61"/>
        <source>Delay</source>
        <translation>Atraso</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_delay/ui.qml" line="63"/>
        <source>The neutral delay time is 2 seconds. Times above 2 seconds will have reduced quality and times below will have increased CPU usage.</source>
        <translation>O tempo neutro de atraso é de 2 segundos. Tempos acima dos 2 segundos terão qualidade reduzida e tempos abaixo aumentam o uso do processador.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_delay/ui.qml" line="82"/>
        <source>Feedback</source>
        <translation>Feedback</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="191"/>
        <source>Attenuation</source>
        <translation>Atenuação</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_expander/ui.qml" line="193"/>
        <source>The gain of the output signal. Used to correct for excessive amplitude caused by the extra dynamic range.</source>
        <translation>Ganho do sinal de saída. Usado para corrigir o excesso de amplitude causado pelo intervalo dinâmico extra.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="74"/>
        <source>Input gain</source>
        <translation>Ganho de entrada</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="76"/>
        <source>Gain that is applied to the input stage. Can be used to trim gain to bring it roughly under the limit or to push the signal against the limit.</source>
        <translation>Ganho que é aplicado na entrada. Pode ser usado para cortar ganho de modo a colocá-lo abaixo do limite ou elevá-lo para junto do limite.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="95"/>
        <source>Limit</source>
        <translation>Limite</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="97"/>
        <source>The maximum output amplitude. Peaks over this level will be attenuated as smoothly as possible to bring them as close as possible to this level.</source>
        <translation>Amplitude máxima de saída. Os picos acima deste nível serão atenuados com a suavidade possível para levá-lo o mais próximo possível deste nível.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_limiter/ui.qml" line="118"/>
        <source>The time taken for the limiter&apos;s attenuation to return to 0 dB&apos;s.</source>
        <translation>Tempo levado pela atenuação do limitador a voltar aos 0 dB.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="37"/>
        <source>Quick fix</source>
        <translation>Reparação rápida</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="46"/>
        <source>Small hall</source>
        <translation>Sala pequena</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="55"/>
        <source>Large hall</source>
        <translation>Sala grande</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="64"/>
        <source>Sewer</source>
        <translation>Esgoto</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="73"/>
        <source>Church</source>
        <translation>Igreja</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="115"/>
        <source>Room size</source>
        <translation>Tamanho da sala</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="117"/>
        <source>The size of the room, in meters. Excessivly large, and excessively small values will make it sound a bit unrealistic.Values of around 30 sound good.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="135"/>
        <source>Reverb time</source>
        <translation>Tempo de reverbação</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="155"/>
        <source>Damping</source>
        <translation>Amortecimento</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="157"/>
        <source>This controls the high frequency damping (a lowpass filter), values near 1 will make it sound very bright, values near 0 will make it sound very dark.</source>
        <translation>Isto controla o amortecimento da alta frequência (um filtro lowpass), volores próximos de 1 tornam o som muito brilhante, próximos de 0 tornam o som muito obscuro.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="176"/>
        <source>Input bandwidth</source>
        <translation>Largura de banda de entrada</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="178"/>
        <source>This is like a damping control for the input, it has a similar effect to the damping control, but is subtly different.</source>
        <translation>É como um controlo de amortecimento para a entrada, tem um efeito semelhante ao controlo de amortecimento, mas é ligeiramente diferente.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="197"/>
        <source>Dry signal level</source>
        <translation>Nível do sinal a seco</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="199"/>
        <source>The amount of dry signal to be mixed with the reverberated signal.</source>
        <translation>A quantidade de sinal a seco para ser misturado com o sinal reverbado.</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="218"/>
        <source>Early reflection level</source>
        <translation>Nível de reflexão inicial</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="238"/>
        <source>Tail level</source>
        <translation>Nível terminal</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="240"/>
        <source>The quantity of early reflections (scatter reflections directly from the source).</source>
        <translation>Quantidade de reflexões iniciais (reflexões espalhadas directamente da origem).</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/audio_reverb/ui.qml" line="260"/>
        <source>About reverb</source>
        <translation>Acerca da reverbação</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/ui.qml" line="48"/>
        <source>Display</source>
        <translation type="unfinished">Exibir</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/ui.qml" line="54"/>
        <source>Gray Alpha</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/ui.qml" line="55"/>
        <source>Red &amp; Gray Alpha</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/ui.qml" line="56"/>
        <source>Checkered Background</source>
        <translation>Fundo Quadriculado</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/ui.qml" line="57"/>
        <source>Black Background</source>
        <translation>Fundo Preto</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/ui.qml" line="58"/>
        <source>Gray Background</source>
        <translation>Fundo Cinzento</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/alpha_view/ui.qml" line="59"/>
        <source>White Background</source>
        <translation>Fundo Branco</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bluescreen0r/ui.qml" line="65"/>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="109"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="120"/>
        <source>Key color</source>
        <translation>Cor Chave</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/bluescreen0r/ui.qml" line="78"/>
        <source>Distance</source>
        <translation>Distância</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="131"/>
        <source>Target color</source>
        <translation>Cor Alvo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="153"/>
        <source>Mask type</source>
        <translation>Tipo de Máscara</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="159"/>
        <source>Color Distance</source>
        <translation>Distância da Cor</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="159"/>
        <source>Transparency</source>
        <translation>Transparência</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="159"/>
        <source>Edge Inwards</source>
        <translation>Beira para Dentro</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="159"/>
        <source>Edge Outwards</source>
        <translation>Beira para Fora</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="167"/>
        <source>Tolerance</source>
        <translation>Tolerância</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="185"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="250"/>
        <location filename="../src/qml/filters/select0r/ui.qml" line="259"/>
        <source>Slope</source>
        <translation>Inclinação</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="203"/>
        <source>Hue gate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="221"/>
        <source>Saturation threshold</source>
        <translation>Limite de Saturação</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="239"/>
        <source>Operation 1</source>
        <translation>Operação 1</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="245"/>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="277"/>
        <source>None</source>
        <translation>Nenhum</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="245"/>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="277"/>
        <source>De-Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="245"/>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="277"/>
        <source>Desaturate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="245"/>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="277"/>
        <source>Adjust Luma</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="253"/>
        <source>Amount 1</source>
        <translation>Quantidade 1</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="271"/>
        <source>Operation 2</source>
        <translation>Operação 2</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="285"/>
        <source>Amount 2</source>
        <translation>Quantidade 2</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="305"/>
        <source>Show mask</source>
        <translation>Mostrar máscara</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/keyspillm0pup/ui.qml" line="315"/>
        <source>Send mask to alpha channel</source>
        <translation>Enviar máscara para o canal alfa</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="142"/>
        <source>Color space</source>
        <translation>Espaço de cor</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="149"/>
        <source>Red-Green-Blue</source>
        <translation>Vermelho-Verde-Azul</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="155"/>
        <source>Hue-Chroma-Intensity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="165"/>
        <source>Red delta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="165"/>
        <source>Hue delta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="183"/>
        <source>Green delta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="183"/>
        <source>Chroma delta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="201"/>
        <source>Blue delta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="201"/>
        <source>Intensity delta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="219"/>
        <source>Shape</source>
        <translation>Contorno</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="227"/>
        <source>Box</source>
        <translation>Caixa</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="228"/>
        <source>Ellipsoid</source>
        <translation>Elipsóide</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="229"/>
        <source>Diamond</source>
        <translation>Losango</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="238"/>
        <source>Edge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="246"/>
        <source>Hard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="247"/>
        <source>Fat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="249"/>
        <source>Thin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="277"/>
        <source>Operation</source>
        <translation>Operação</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="285"/>
        <source>Write on Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="286"/>
        <source>Maximum</source>
        <translation>Máximo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="287"/>
        <source>Minimum</source>
        <translation>Mínimo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="288"/>
        <source>Add</source>
        <translation>Adicionar</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/select0r/ui.qml" line="289"/>
        <source>Subtract</source>
        <translation>Subtrair</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/contrast/ui.qml" line="66"/>
        <source>Contrast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/smartblur/ui.qml" line="68"/>
        <source>Blur Radius</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/smartblur/ui.qml" line="70"/>
        <source>The radius of the gaussian blur.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/smartblur/ui.qml" line="88"/>
        <source>Blur Strength</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/smartblur/ui.qml" line="90"/>
        <source>The strength of the gaussian blur.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qml/filters/smartblur/ui.qml" line="110"/>
        <source>If the difference between the original pixel and the blurred pixel is less than threshold, the pixel will be replaced with the blurred pixel.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ui_boxblur</name>
    <message>
        <location filename="../src/qml/filters/blur/ui_boxblur.qml" line="44"/>
        <source>Width</source>
        <translation>Largura</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/ui_boxblur.qml" line="60"/>
        <source>Height</source>
        <translation>Altura</translation>
    </message>
</context>
<context>
    <name>ui_frei0r</name>
    <message>
        <location filename="../src/qml/filters/saturation/ui_frei0r.qml" line="57"/>
        <source>Saturation</source>
        <translation>Saturação</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/ui_frei0r.qml" line="45"/>
        <location filename="../src/qml/filters/saturation/ui_frei0r.qml" line="44"/>
        <location filename="../src/qml/filters/sharpen/ui_frei0r.qml" line="47"/>
        <source>Preset</source>
        <translation>Predefinição</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/ui_frei0r.qml" line="57"/>
        <source>Blur</source>
        <translation>Desfocar</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/ui_frei0r.qml" line="60"/>
        <source>Amount</source>
        <translation>Quantidade</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/ui_frei0r.qml" line="77"/>
        <source>Size</source>
        <translation>Tamanho</translation>
    </message>
</context>
<context>
    <name>ui_frei0r_coloradj</name>
    <message>
        <location filename="../src/qml/filters/color/ui_frei0r_coloradj.qml" line="60"/>
        <source>Mode</source>
        <translation>Modo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/ui_frei0r_coloradj.qml" line="64"/>
        <source>Shadows (Lift)</source>
        <translation>Sombras (Elevação)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/ui_frei0r_coloradj.qml" line="64"/>
        <source>Midtones (Gamma)</source>
        <translation>Meios Tons (Gama)</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/color/ui_frei0r_coloradj.qml" line="64"/>
        <source>Highlights (Gain)</source>
        <translation>Realces (Ganho)</translation>
    </message>
</context>
<context>
    <name>ui_movit</name>
    <message>
        <location filename="../src/qml/filters/saturation/ui_movit.qml" line="43"/>
        <source>Saturation</source>
        <translation>Saturação</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/blur/ui_movit.qml" line="33"/>
        <location filename="../src/qml/filters/glow/ui_movit.qml" line="63"/>
        <source>Radius</source>
        <translation>Raio</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/ui_movit.qml" line="65"/>
        <source>Circle radius</source>
        <translation>Raio do círculo</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/ui_movit.qml" line="83"/>
        <source>Gaussian radius</source>
        <translation>Raio Gaussiano</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/ui_movit.qml" line="101"/>
        <source>Correlation</source>
        <translation>Correlação</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/sharpen/ui_movit.qml" line="118"/>
        <source>Noise</source>
        <translation>Ruído</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/ui_movit.qml" line="48"/>
        <location filename="../src/qml/filters/sharpen/ui_movit.qml" line="49"/>
        <location filename="../src/qml/filters/vignette/ui_movit.qml" line="38"/>
        <source>Preset</source>
        <translation>Predefinição</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/ui_movit.qml" line="80"/>
        <source>Highlight blurriness</source>
        <translation>Realçar desfocagem</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/glow/ui_movit.qml" line="97"/>
        <source>Highlight cutoff</source>
        <translation>Realçar cortes</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/ui_movit.qml" line="52"/>
        <source>Outer radius</source>
        <translation>Raio exterior</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/ui_movit.qml" line="68"/>
        <source>Inner radius</source>
        <translation>Raio interior</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/brightness/ui_movit.qml" line="42"/>
        <source>Brightness</source>
        <translation type="unfinished">Brilho</translation>
    </message>
</context>
<context>
    <name>ui_oldfilm</name>
    <message>
        <location filename="../src/qml/filters/vignette/ui_oldfilm.qml" line="38"/>
        <source>Preset</source>
        <translation>Predefinição</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/ui_oldfilm.qml" line="54"/>
        <source>Radius</source>
        <translation>Raio</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/ui_oldfilm.qml" line="70"/>
        <source>Feathering</source>
        <translation>Suavização</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/ui_oldfilm.qml" line="88"/>
        <source>Non-linear feathering</source>
        <translation>Suavização não linear</translation>
    </message>
    <message>
        <location filename="../src/qml/filters/vignette/ui_oldfilm.qml" line="100"/>
        <source>Opacity</source>
        <translation>Opacidade</translation>
    </message>
</context>
</TS>
