This tracker is for defects only! For feature requests, see [our patron forum](https://www.shotcut.org/discussionforum/).

If you’re reporting a defect, make it as detailed as possible, and include both your OS and Shotcut versions (e.g. `OS X 10.11.5; Shotcut 16.05.01`).
